package IDAOs;
    import Clases.Cita;
    import java.util.ArrayList;

public interface IDaoCita {
    void altasCita(Cita cita);
    void bajasCita(int id);
    void modificarCita(Cita citaModificada);
    ArrayList<Cita> obtenerTodasCitas();
    Cita buscarCita(int id);
    void guardarCitas(ArrayList<Cita> citas);
}
