package IDAOs;
    import Clases.Medico;
    import java.util.ArrayList;

public interface IDaoMedico {
    void altasMedico(Medico medico);
    void bajasMedico(int id);
    void modificarMedico(Medico medicoModificado);
    ArrayList<Medico> obtenerTodosMedicos();
    Medico buscarMedico(int id);
    void guardarMedicos(ArrayList<Medico> medicos);
}

