package IDAOs;
    import Clases.HistorialMedico;
    import java.util.ArrayList;

public interface IDaoHistorialMedico {
    void altasHistorialMedico(HistorialMedico historialMedico);
    void bajasHistorialMedico(int id);
    void modificarHistorialMedico(HistorialMedico historialMedicoModificado);
    ArrayList<HistorialMedico> obtenerTodosHistorialesMedicos();
    HistorialMedico buscarHistorialMedico(int id);
    void guardarHistorialesMedicos(ArrayList<HistorialMedico> historialesMedicos);
}
