package IDAOs;
    import Clases.Habitacion;
    import java.util.ArrayList;

public interface IDaoHabitacion {
    void altasHabitacion(Habitacion habitacion);
    void bajasHabitacion(int id);
    void modificarHabitacion(Habitacion habitacionModificada);
    ArrayList<Habitacion> obtenerTodasHabitaciones();
    Habitacion buscarHabitacion(int id);
    void guardarHabitaciones(ArrayList<Habitacion> habitaciones);
}
