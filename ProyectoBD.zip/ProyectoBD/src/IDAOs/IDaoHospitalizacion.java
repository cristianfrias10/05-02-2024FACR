package IDAOs;
    import Clases.Hospitalizacion;
    import java.util.ArrayList;

public interface IDaoHospitalizacion {
    void altasHospitalizacion(Hospitalizacion hospitalizacion);
    void bajasHospitalizacion(int id);
    void modificarHospitalizacion(Hospitalizacion hospitalizacionModificada);
    ArrayList<Hospitalizacion> obtenerTodasHospitalizaciones();
    Hospitalizacion buscarHospitalizacion(int id);
    void guardarHospitalizaciones(ArrayList<Hospitalizacion> hospitalizaciones);
}
