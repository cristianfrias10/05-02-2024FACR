package IDAOs;
    import Clases.Paciente;
    import java.util.ArrayList;

public interface IDaoPaciente {
    void altasPaciente(Paciente paciente);
    void bajasPaciente(int id);
    void modificarPaciente(Paciente pacienteModificado);
    ArrayList<Paciente> obtenerTodosPacientes();
    Paciente buscarPaciente(int id);
    void guardarPacientes(ArrayList<Paciente> pacientes);
}
