package Clases;


public class HistorialMedico {
    private int id;
    private int paciente_id;
    private int medico_id;
    private String fecha_registro;
    private String diagnostico;
    private String tratamiento;

    public HistorialMedico(int id, int paciente_id, int medico_id, String fecha_registro, String diagnostico, String tratamiento) {
        this.id = id;
        this.paciente_id = paciente_id;
        this.medico_id = medico_id;
        this.fecha_registro = fecha_registro;
        this.diagnostico = diagnostico;
        this.tratamiento = tratamiento;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPaciente_id() {
        return paciente_id;
    }

    public void setPaciente_id(int paciente_id) {
        this.paciente_id = paciente_id;
    }

    public int getMedico_id() {
        return medico_id;
    }

    public void setMedico_id(int medico_id) {
        this.medico_id = medico_id;
    }

    public String getFecha_registro() {
        return fecha_registro;
    }

    public void setFecha_registro(String fecha_registro) {
        this.fecha_registro = fecha_registro;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public String getTratamiento() {
        return tratamiento;
    }

    public void setTratamiento(String tratamiento) {
        this.tratamiento = tratamiento;
    }
    
    @Override
    public String toString()
    {
        return String.format("%20d %20d %20d %20s %20s %20s", id, paciente_id, medico_id, fecha_registro, diagnostico, tratamiento);
    }
}
