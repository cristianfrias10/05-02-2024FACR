package Clases;


public class Cita {
    private int id;
    private int paciente_id;
    private int medico_id;
    private String fecha_cita;
    private String hora_cita;

    public Cita(int id, int paciente_id, int medico_id, String fecha_cita, String hora_cita) {
        this.id = id;
        this.paciente_id = paciente_id;
        this.medico_id = medico_id;
        this.fecha_cita = fecha_cita;
        this.hora_cita = hora_cita;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPaciente_id() {
        return paciente_id;
    }

    public void setPaciente_id(int paciente_id) {
        this.paciente_id = paciente_id;
    }

    public int getMedico_id() {
        return medico_id;
    }

    public void setMedico_id(int medico_id) {
        this.medico_id = medico_id;
    }

    public String getFecha_cita() {
        return fecha_cita;
    }

    public void setFecha_cita(String fecha_cita) {
        this.fecha_cita = fecha_cita;
    }

    public String getHora_cita() {
        return hora_cita;
    }

    public void setHora_cita(String hora_cita) {
        this.hora_cita = hora_cita;
    }
    
    @Override
    public String toString()
    {
        return String.format("%20d %20d %20d %20s %20s",id, paciente_id, medico_id, fecha_cita, hora_cita);
    }
}
