package Clases;


public class Hospitalizacion {
    private int id;
    private int paciente_id;
    private int habitacion_id;
    private String fecha_ingreso;
    private String fecha_alta;

    public Hospitalizacion(int id, int paciente_id, int habitacion_id, String fecha_ingreso, String fecha_alta) {
        this.id = id;
        this.paciente_id = paciente_id;
        this.habitacion_id = habitacion_id;
        this.fecha_ingreso = fecha_ingreso;
        this.fecha_alta = fecha_alta;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPaciente_id() {
        return paciente_id;
    }

    public void setPaciente_id(int paciente_id) {
        this.paciente_id = paciente_id;
    }

    public int getHabitacion_id() {
        return habitacion_id;
    }

    public void setHabitacion_id(int habitacion_id) {
        this.habitacion_id = habitacion_id;
    }

    public String getFecha_ingreso() {
        return fecha_ingreso;
    }

    public void setFecha_ingreso(String fecha_ingreso) {
        this.fecha_ingreso = fecha_ingreso;
    }

    public String getFecha_alta() {
        return fecha_alta;
    }

    public void setFecha_alta(String fecha_alta) {
        this.fecha_alta = fecha_alta;
    }
    
    @Override
    public String toString()
    {
        return String.format("%20d %20d %20d %20s %20s",id, paciente_id, habitacion_id, fecha_ingreso, fecha_alta);
    }
}
