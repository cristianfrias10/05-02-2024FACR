package MenuPrincipal;
    import Usuarios.UserDAO;
    import javax.swing.*;
    import java.awt.*;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;

public class PermissionFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> databaseComboBox;
    private JComboBox<String> tableComboBox;
    private JComboBox<String> permissionsComboBox;
    private UserDAO userDAO;
    private JButton btnRegresar;

    public PermissionFrame() {
        userDAO = new UserDAO();

        setTitle("REGISTRAR USUARIOS");
        setSize(640, 320);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new java.awt.Color(204, 204, 204));

        JLabel lblTitulo = new JLabel("SISTEMA DE REGISTROS Y PERMISOS");
        lblTitulo.setBounds(150, 10, 300, 25);
        add(lblTitulo);
        
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(50, 50, 100, 25);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(160, 50, 200, 25);
        add(usernameField);

        JLabel passwordLabel = new JLabel("Contraseña:");
        passwordLabel.setBounds(50, 80, 100, 25);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(160, 80, 200, 25);
        add(passwordField);

        JButton registerButton = new JButton("Registrar");
        registerButton.setBounds(390, 60, 100, 30);
        registerButton.setBackground(new java.awt.Color(153,255,153));
        registerButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        registerButton.addActionListener(new RegisterButtonListener());
        add(registerButton);

        JLabel databaseLabel = new JLabel("Database:");
        databaseLabel.setBounds(50, 150, 100, 25);
        add(databaseLabel);

        String[] databases = {"HospitalSystem"};
        databaseComboBox = new JComboBox<>(databases);
        databaseComboBox.setBounds(160, 150, 200, 25);
        add(databaseComboBox);

        JLabel tableLabel = new JLabel("Table:");
        tableLabel.setBounds(50, 180, 100, 25);
        add(tableLabel);

        String[] tables = {"paciente", "medico", "cita", "historial_medico", "habitacion", "hospitalizacion"};
        tableComboBox = new JComboBox<>(tables);
        tableComboBox.setBounds(160, 180, 200, 25);
        add(tableComboBox);

        JLabel permissionsLabel = new JLabel("Permisos:");
        permissionsLabel.setBounds(50, 210, 250, 25);
        add(permissionsLabel);

        String[] permissions = {"SELECT", "INSERT", "UPDATE", "DELETE"};
        permissionsComboBox = new JComboBox<>(permissions);
        permissionsComboBox.setBounds(160, 210, 200, 25);
        add(permissionsComboBox);

        JButton grantButton = new JButton("Dar Permisos");
        grantButton.setBounds(390, 150, 150, 30);
        grantButton.setBackground(new java.awt.Color(153,204,255));
        grantButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        grantButton.addActionListener(new GrantButtonListener());
        add(grantButton);

        JButton revokeButton = new JButton("Quitar Permisos");
        revokeButton.setBounds(390, 200, 150, 30);
        revokeButton.setBackground(new java.awt.Color(153,204,255));
        revokeButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        revokeButton.addActionListener(new RevokeButtonListener());
        add(revokeButton);
        
        btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(250, 240, 100, 40);
        btnRegresar.setBackground(new java.awt.Color(192,192,192));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((ActionEvent e) -> {
            this.dispose();
            
            VPrincipal.V2 lf = new VPrincipal.V2();
            lf.setVisible(true);
        });
        add(btnRegresar);
    }

    private class RegisterButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (userDAO.registerUser(username, password)) {
                JOptionPane.showMessageDialog(PermissionFrame.this, "User registered successfully!");
            } else {
                JOptionPane.showMessageDialog(PermissionFrame.this, "User registration failed.");
            }
        }
    }

    private class GrantButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText();
            String database = (String) databaseComboBox.getSelectedItem();
            String table = (String) tableComboBox.getSelectedItem();
            String permissions = (String) permissionsComboBox.getSelectedItem();

            if (userDAO.grantPermissions(username, database, table, permissions)) {
                JOptionPane.showMessageDialog(PermissionFrame.this, "Permissions granted successfully!");
            } else {
                JOptionPane.showMessageDialog(PermissionFrame.this, "Failed to grant permissions.");
            }
        }
    }

    private class RevokeButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText();
            String database = (String) databaseComboBox.getSelectedItem();
            String table = (String) tableComboBox.getSelectedItem();
            String permissions = (String) permissionsComboBox.getSelectedItem();

            if (userDAO.revokePermissions(username, database, table, permissions)) {
                JOptionPane.showMessageDialog(PermissionFrame.this, "Permissions revoked successfully!");
            } else {
                JOptionPane.showMessageDialog(PermissionFrame.this, "Failed to revoke permissions.");
            }
        }
    }
}