package MenuPrincipal;


public class MP extends javax.swing.JFrame {

    public MP() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTextoC = new javax.swing.JLabel();
        btnCita = new javax.swing.JButton();
        btnHistoriales = new javax.swing.JButton();
        btnHabitacion = new javax.swing.JButton();
        btnHospitalizacion = new javax.swing.JButton();
        btnMedico = new javax.swing.JButton();
        btnPaciente = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        menuR = new javax.swing.JMenu();
        MRegresar = new javax.swing.JMenuItem();
        menuC = new javax.swing.JMenu();
        menuCitas = new javax.swing.JMenu();
        altasCitas = new javax.swing.JMenuItem();
        bajasCitas = new javax.swing.JMenuItem();
        modificarCitas = new javax.swing.JMenuItem();
        reportesCitas = new javax.swing.JMenuItem();
        menuHabitaciones = new javax.swing.JMenu();
        altasHabitacion = new javax.swing.JMenuItem();
        bajasHabitacion = new javax.swing.JMenuItem();
        modificarHabitacion = new javax.swing.JMenuItem();
        reportesHabitacion = new javax.swing.JMenuItem();
        menuHistoriales = new javax.swing.JMenu();
        altasHistorial = new javax.swing.JMenuItem();
        bajasHistorial = new javax.swing.JMenuItem();
        modificarHistorial = new javax.swing.JMenuItem();
        reportesHistorial = new javax.swing.JMenuItem();
        menuHospitalizacion = new javax.swing.JMenu();
        altasHospital = new javax.swing.JMenuItem();
        bajasHospital = new javax.swing.JMenuItem();
        modificarHospital = new javax.swing.JMenuItem();
        reportesHospital = new javax.swing.JMenuItem();
        menuMedicos = new javax.swing.JMenu();
        altasMedico = new javax.swing.JMenuItem();
        bajasMedico = new javax.swing.JMenuItem();
        modificarMedico = new javax.swing.JMenuItem();
        reportesMedico = new javax.swing.JMenuItem();
        menuPacientes = new javax.swing.JMenu();
        altasPaciente = new javax.swing.JMenuItem();
        bajasPaciente = new javax.swing.JMenuItem();
        modificarPaciente = new javax.swing.JMenuItem();
        reportesPaciente = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu Principal");

        lblTextoC.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblTextoC.setText("PANEL DE CONTROL DEL CENTRO DE SALUD");

        btnCita.setBackground(new java.awt.Color(204, 204, 204));
        btnCita.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCita.setText("Agendar Citas");
        btnCita.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCitaActionPerformed(evt);
            }
        });

        btnHistoriales.setBackground(new java.awt.Color(204, 204, 204));
        btnHistoriales.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnHistoriales.setText("Historiales Medicos de Pacientes");
        btnHistoriales.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnHistoriales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHistorialesActionPerformed(evt);
            }
        });

        btnHabitacion.setBackground(new java.awt.Color(204, 204, 204));
        btnHabitacion.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnHabitacion.setText("Habitaciones de Hospital");
        btnHabitacion.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHabitacionActionPerformed(evt);
            }
        });

        btnHospitalizacion.setBackground(new java.awt.Color(204, 204, 204));
        btnHospitalizacion.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnHospitalizacion.setText("Registros de Pacientes");
        btnHospitalizacion.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnHospitalizacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHospitalizacionActionPerformed(evt);
            }
        });

        btnMedico.setBackground(new java.awt.Color(204, 204, 204));
        btnMedico.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnMedico.setText("Medicos");
        btnMedico.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnMedico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMedicoActionPerformed(evt);
            }
        });

        btnPaciente.setBackground(new java.awt.Color(204, 204, 204));
        btnPaciente.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnPaciente.setText("Pacientes");
        btnPaciente.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnPaciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPacienteActionPerformed(evt);
            }
        });

        btnSalir.setBackground(new java.awt.Color(204, 204, 204));
        btnSalir.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnSalir.setText("Regresar");
        btnSalir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        menuBar.setBackground(new java.awt.Color(204, 204, 204));

        menuR.setText("Archivo");

        MRegresar.setText("Regresar");
        MRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MRegresarActionPerformed(evt);
            }
        });
        menuR.add(MRegresar);

        menuBar.add(menuR);

        menuC.setText("Catalogo");

        menuCitas.setText("Citas");

        altasCitas.setText("Altas Citas");
        altasCitas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                altasCitasActionPerformed(evt);
            }
        });
        menuCitas.add(altasCitas);

        bajasCitas.setText("Bajas Citas");
        bajasCitas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bajasCitasActionPerformed(evt);
            }
        });
        menuCitas.add(bajasCitas);

        modificarCitas.setText("Modificar Citas");
        modificarCitas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarCitasActionPerformed(evt);
            }
        });
        menuCitas.add(modificarCitas);

        reportesCitas.setText("Reportes Citas");
        reportesCitas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportesCitasActionPerformed(evt);
            }
        });
        menuCitas.add(reportesCitas);

        menuC.add(menuCitas);

        menuHabitaciones.setText("Habitaciones");
        menuHabitaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuHabitacionesActionPerformed(evt);
            }
        });

        altasHabitacion.setText("Altas Habitaciones");
        altasHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                altasHabitacionActionPerformed(evt);
            }
        });
        menuHabitaciones.add(altasHabitacion);

        bajasHabitacion.setText("Bajas Habitaciones");
        bajasHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bajasHabitacionActionPerformed(evt);
            }
        });
        menuHabitaciones.add(bajasHabitacion);

        modificarHabitacion.setText("Modificar Habitaciones");
        modificarHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarHabitacionActionPerformed(evt);
            }
        });
        menuHabitaciones.add(modificarHabitacion);

        reportesHabitacion.setText("Reportes Habitaciones");
        reportesHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportesHabitacionActionPerformed(evt);
            }
        });
        menuHabitaciones.add(reportesHabitacion);

        menuC.add(menuHabitaciones);

        menuHistoriales.setText("Historiales Medicos");

        altasHistorial.setText("Altas Historiales");
        altasHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                altasHistorialActionPerformed(evt);
            }
        });
        menuHistoriales.add(altasHistorial);

        bajasHistorial.setText("Bajas Historiales");
        bajasHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bajasHistorialActionPerformed(evt);
            }
        });
        menuHistoriales.add(bajasHistorial);

        modificarHistorial.setText("Modificar Historiales");
        modificarHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarHistorialActionPerformed(evt);
            }
        });
        menuHistoriales.add(modificarHistorial);

        reportesHistorial.setText("Reportes Historiales");
        reportesHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportesHistorialActionPerformed(evt);
            }
        });
        menuHistoriales.add(reportesHistorial);

        menuC.add(menuHistoriales);

        menuHospitalizacion.setText("Hospitalizacion");

        altasHospital.setText("Altas Hospitalizacion");
        altasHospital.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                altasHospitalActionPerformed(evt);
            }
        });
        menuHospitalizacion.add(altasHospital);

        bajasHospital.setText("Bajas Hospitalizacion");
        bajasHospital.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bajasHospitalActionPerformed(evt);
            }
        });
        menuHospitalizacion.add(bajasHospital);

        modificarHospital.setText("Modificar Hospitalizacion");
        modificarHospital.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarHospitalActionPerformed(evt);
            }
        });
        menuHospitalizacion.add(modificarHospital);

        reportesHospital.setText("Reportes Hospitalizacion");
        reportesHospital.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportesHospitalActionPerformed(evt);
            }
        });
        menuHospitalizacion.add(reportesHospital);

        menuC.add(menuHospitalizacion);

        menuMedicos.setText("Medicos");

        altasMedico.setText("Altas Medicos");
        menuMedicos.add(altasMedico);

        bajasMedico.setText("Bajas Medicos");
        menuMedicos.add(bajasMedico);

        modificarMedico.setText("Modificar Medicos");
        menuMedicos.add(modificarMedico);

        reportesMedico.setText("Reportes Medicos");
        menuMedicos.add(reportesMedico);

        menuC.add(menuMedicos);

        menuPacientes.setText("Pacientes");

        altasPaciente.setText("Altas Pacientes");
        menuPacientes.add(altasPaciente);

        bajasPaciente.setText("Bajas Pacientes");
        menuPacientes.add(bajasPaciente);

        modificarPaciente.setText("Modificar Pacientes");
        menuPacientes.add(modificarPaciente);

        reportesPaciente.setText("Reportes Pacientes");
        menuPacientes.add(reportesPaciente);

        menuC.add(menuPacientes);

        menuBar.add(menuC);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(134, 134, 134)
                .addComponent(lblTextoC)
                .addGap(52, 52, 52))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(btnMedico, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnHabitacion, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(btnCita, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 101, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnHospitalizacion, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(87, 87, 87))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnHistoriales, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnMedico, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(btnCita, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnHabitacion, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(lblTextoC, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                        .addComponent(btnHistoriales, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnHospitalizacion, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)))
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnHistorialesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHistorialesActionPerformed
        this.dispose();
        
        MenusOpciones.MPHistorialMedico mohm = new MenusOpciones.MPHistorialMedico();
        mohm.setVisible(true);
    }//GEN-LAST:event_btnHistorialesActionPerformed

    private void btnHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHabitacionActionPerformed
        this.dispose();
        
        MenusOpciones.MPHabitacion moh = new MenusOpciones.MPHabitacion();
        moh.setVisible(true);
    }//GEN-LAST:event_btnHabitacionActionPerformed

    private void btnHospitalizacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHospitalizacionActionPerformed
        this.dispose();
        
        MenusOpciones.MPHospitalizacion MPM = new MenusOpciones.MPHospitalizacion();
        MPM.setVisible(true);
    }//GEN-LAST:event_btnHospitalizacionActionPerformed

    private void btnCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCitaActionPerformed
        this.dispose();
        
        MenusOpciones.MPCita moc = new MenusOpciones.MPCita();
        moc.setVisible(true);
    }//GEN-LAST:event_btnCitaActionPerformed

    private void btnMedicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMedicoActionPerformed
        this.dispose();
        
        MenusOpciones.MPMedico mom = new MenusOpciones.MPMedico();
        mom.setVisible(true);
    }//GEN-LAST:event_btnMedicoActionPerformed

    private void MRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MRegresarActionPerformed
        this.dispose();
        
        VPrincipal.V2 v2 = new VPrincipal.V2();
        v2.setVisible(true);
    }//GEN-LAST:event_MRegresarActionPerformed

    private void altasCitasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_altasCitasActionPerformed
        this.dispose();
        
        CRUDCita.AltasCita altas = new CRUDCita.AltasCita();
        altas.setVisible(true);
    }//GEN-LAST:event_altasCitasActionPerformed

    private void bajasCitasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bajasCitasActionPerformed
        this.dispose();
        
        CRUDCita.BajasCita bajas = new CRUDCita.BajasCita();
        bajas.setVisible(true);
    }//GEN-LAST:event_bajasCitasActionPerformed

    private void modificarCitasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarCitasActionPerformed
        this.dispose();
        
        CRUDCita.ModificarCita modificar = new CRUDCita.ModificarCita();
        modificar.setVisible(true);
    }//GEN-LAST:event_modificarCitasActionPerformed

    private void reportesCitasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportesCitasActionPerformed
        this.dispose();
        
        CRUDCita.MDCita reportes = new CRUDCita.MDCita();
        reportes.setVisible(true);
    }//GEN-LAST:event_reportesCitasActionPerformed

    private void menuHabitacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuHabitacionesActionPerformed

    }//GEN-LAST:event_menuHabitacionesActionPerformed

    private void altasHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_altasHabitacionActionPerformed
        this.dispose();
        
        CRUDHabitacion.AltasHabitacion altas = new CRUDHabitacion.AltasHabitacion();
        altas.setVisible(true);
    }//GEN-LAST:event_altasHabitacionActionPerformed

    private void bajasHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bajasHabitacionActionPerformed
        this.dispose();
        
        CRUDHabitacion.BajasHabitacion bajas = new CRUDHabitacion.BajasHabitacion();
        bajas.setVisible(true);
    }//GEN-LAST:event_bajasHabitacionActionPerformed

    private void modificarHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarHabitacionActionPerformed
        this.dispose();
        
        CRUDHabitacion.ModificarHabitacion modificar = new CRUDHabitacion.ModificarHabitacion();
        modificar.setVisible(true);
    }//GEN-LAST:event_modificarHabitacionActionPerformed

    private void reportesHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportesHabitacionActionPerformed
        this.dispose();
        
        CRUDHabitacion.MDHabitacion reportes = new CRUDHabitacion.MDHabitacion();
        reportes.setVisible(true);
    }//GEN-LAST:event_reportesHabitacionActionPerformed

    private void altasHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_altasHistorialActionPerformed
        this.dispose();
        
        CRUDHistorialMedico.AltasHistorialMedico altas = new CRUDHistorialMedico.AltasHistorialMedico();
        altas.setVisible(true);
    }//GEN-LAST:event_altasHistorialActionPerformed

    private void bajasHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bajasHistorialActionPerformed
        this.dispose();
        
        CRUDHistorialMedico.BajasHistorialMedico bajas = new CRUDHistorialMedico.BajasHistorialMedico();
        bajas.setVisible(true);
    }//GEN-LAST:event_bajasHistorialActionPerformed

    private void modificarHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarHistorialActionPerformed
        this.dispose();
        
        CRUDHistorialMedico.ModificarHistorialMedico modificar = new CRUDHistorialMedico.ModificarHistorialMedico();
        modificar.setVisible(true);
    }//GEN-LAST:event_modificarHistorialActionPerformed

    private void reportesHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportesHistorialActionPerformed
        this.dispose();
        
        CRUDHistorialMedico.MDHistorialMedico reportes = new CRUDHistorialMedico.MDHistorialMedico();
        reportes.setVisible(true);
    }//GEN-LAST:event_reportesHistorialActionPerformed

    private void altasHospitalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_altasHospitalActionPerformed
        this.dispose();
        
        CRUDHospitalizacion.AltasHospitalizacion altas = new CRUDHospitalizacion.AltasHospitalizacion();
        altas.setVisible(true);
    }//GEN-LAST:event_altasHospitalActionPerformed

    private void bajasHospitalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bajasHospitalActionPerformed
        this.dispose();
        
        CRUDHospitalizacion.BajasHospitalizacion bajas = new CRUDHospitalizacion.BajasHospitalizacion();
        bajas.setVisible(true);
    }//GEN-LAST:event_bajasHospitalActionPerformed

    private void modificarHospitalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarHospitalActionPerformed
        this.dispose();
        
        CRUDHospitalizacion.ModificarHospitalizacion modificar = new CRUDHospitalizacion.ModificarHospitalizacion();
        modificar.setVisible(true);
    }//GEN-LAST:event_modificarHospitalActionPerformed

    private void reportesHospitalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportesHospitalActionPerformed
        this.dispose();
        
        CRUDHospitalizacion.MDHospitalizacion reportes = new CRUDHospitalizacion.MDHospitalizacion();
        reportes.setVisible(true);
    }//GEN-LAST:event_reportesHospitalActionPerformed

    private void btnPacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPacienteActionPerformed
        this.dispose();
        
        MenusOpciones.MPPaciente mop = new MenusOpciones.MPPaciente();
        mop.setVisible(true);
    }//GEN-LAST:event_btnPacienteActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
        
        VPrincipal.V2 v2 = new VPrincipal.V2();
        v2.setVisible(true);
    }//GEN-LAST:event_btnSalirActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem MRegresar;
    private javax.swing.JMenuItem altasCitas;
    private javax.swing.JMenuItem altasHabitacion;
    private javax.swing.JMenuItem altasHistorial;
    private javax.swing.JMenuItem altasHospital;
    private javax.swing.JMenuItem altasMedico;
    private javax.swing.JMenuItem altasPaciente;
    private javax.swing.JMenuItem bajasCitas;
    private javax.swing.JMenuItem bajasHabitacion;
    private javax.swing.JMenuItem bajasHistorial;
    private javax.swing.JMenuItem bajasHospital;
    private javax.swing.JMenuItem bajasMedico;
    private javax.swing.JMenuItem bajasPaciente;
    private javax.swing.JButton btnCita;
    private javax.swing.JButton btnHabitacion;
    private javax.swing.JButton btnHistoriales;
    private javax.swing.JButton btnHospitalizacion;
    private javax.swing.JButton btnMedico;
    private javax.swing.JButton btnPaciente;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel lblTextoC;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenu menuC;
    private javax.swing.JMenu menuCitas;
    private javax.swing.JMenu menuHabitaciones;
    private javax.swing.JMenu menuHistoriales;
    private javax.swing.JMenu menuHospitalizacion;
    private javax.swing.JMenu menuMedicos;
    private javax.swing.JMenu menuPacientes;
    private javax.swing.JMenu menuR;
    private javax.swing.JMenuItem modificarCitas;
    private javax.swing.JMenuItem modificarHabitacion;
    private javax.swing.JMenuItem modificarHistorial;
    private javax.swing.JMenuItem modificarHospital;
    private javax.swing.JMenuItem modificarMedico;
    private javax.swing.JMenuItem modificarPaciente;
    private javax.swing.JMenuItem reportesCitas;
    private javax.swing.JMenuItem reportesHabitacion;
    private javax.swing.JMenuItem reportesHistorial;
    private javax.swing.JMenuItem reportesHospital;
    private javax.swing.JMenuItem reportesMedico;
    private javax.swing.JMenuItem reportesPaciente;
    // End of variables declaration//GEN-END:variables
}
