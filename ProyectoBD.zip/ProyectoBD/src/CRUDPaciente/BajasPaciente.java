package CRUDPaciente;


public class BajasPaciente extends javax.swing.JFrame {
    private java.util.ArrayList<Clases.Paciente> pacientes;
    
    private int indiceActual = 0;
    
    private javax.swing.JLabel lblElegir;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblApellidos;
    private javax.swing.JLabel lblFechaNacimiento;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblTelefono;

    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnBuscar;
    
    private javax.swing.JTextField txtElegir;
    
    public BajasPaciente() {
        super.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 320;
        d.width = 640;

        super.setSize(d);
        super.setTitle("BAJAS PACIENTES");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(229,204,255));
        
        lblElegir = new javax.swing.JLabel("ID de Paciente: ");
        lblElegir.setBounds(50, 20, 180, 30);

        lblID = new javax.swing.JLabel("ID:");
        lblID.setBounds(50, 80, 180, 30);

        lblNombre = new javax.swing.JLabel("Nombre:");
        lblNombre.setBounds(50, 110, 180, 30);

        lblApellidos = new javax.swing.JLabel("Apellidos:");
        lblApellidos.setBounds(50, 140, 180, 30);

        lblFechaNacimiento = new javax.swing.JLabel("Fecha de Nacimiento:");
        lblFechaNacimiento.setBounds(50, 170, 180, 30);

        lblDireccion = new javax.swing.JLabel("Dirección:");
        lblDireccion.setBounds(50, 200, 180, 30);

        lblTelefono = new javax.swing.JLabel("Teléfono:");
        lblTelefono.setBounds(50, 230, 180, 30);

        btnBorrar = new javax.swing.JButton("Dar de Baja");
        btnBorrar.setBounds(460, 100, 130, 40);
        btnBorrar.setBackground(new java.awt.Color(175, 238, 238));
        btnBorrar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnBorrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBorrar.addActionListener((java.awt.event.ActionEvent e) -> {
            DAOs.DaoPaciente daoPaciente = new DAOs.DaoPaciente();
            String idText = txtElegir.getText();
            
            try {
                int id = Integer.parseInt(idText);
                Clases.Paciente pacienteBorrar = daoPaciente.buscarPaciente(id);
                
                if (pacienteBorrar != null) {
                    daoPaciente.bajasPaciente(id);
                    javax.swing.JOptionPane.showMessageDialog(this, "Paciente borrado exitosamente.");
                    
                    lblID.setText("ID");
                    lblNombre.setText("Nombre");
                    lblApellidos.setText("Apellidos");
                    lblFechaNacimiento.setText("Fecha de Nacimiento");
                    lblDireccion.setText("Dirección");
                    lblTelefono.setText("Teléfono");
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "ID de Paciente no encontrado.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID de Paciente.");
            }
            txtElegir.setText("");
        });
        
        btnBuscar = new javax.swing.JButton("Buscar");
        btnBuscar.setBounds(350, 20, 100, 30);
        btnBuscar.setBackground(new java.awt.Color(175, 238, 238));
        btnBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((java.awt.event.ActionEvent e)-> {
            DAOs.DaoPaciente daoPaciente = new DAOs.DaoPaciente();
            String idText = txtElegir.getText();
            txtElegir.setText("");
            
            try {
                int id = Integer.parseInt(idText);
                Clases.Paciente paciente = daoPaciente.buscarPaciente(id);
                
                if (paciente != null) {
                    mostrarDatos(paciente);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "ID de Paciente no encontrado.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID de Paciente.");
            }
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(460, 150, 130, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();

            MenusOpciones.MPPaciente menuPrincipal = new MenusOpciones.MPPaciente();
            menuPrincipal.setVisible(true);
        });
        
        txtElegir = new javax.swing.JTextField();
        txtElegir.setBounds (180, 20, 150, 30);
        
        mostrarDatos(indiceActual);

        super.add(lblElegir);
        super.add(lblID);
        super.add(lblNombre);
        super.add(lblApellidos);
        super.add(lblFechaNacimiento);
        super.add(lblDireccion);
        super.add(lblTelefono);
        
        super.add(btnBorrar);
        super.add(btnRegresar);
        super.add(btnBuscar);
        
        super.add(txtElegir);
        
    }

    private void mostrarDatos(int index) {
        DAOs.DaoPaciente daoPaciente = new DAOs.DaoPaciente();
        pacientes = daoPaciente.obtenerTodosPacientes();
        
        if (index >= 0 && index < pacientes.size()) {
            Clases.Paciente paciente = pacientes.get(index);
            lblID.setText("ID: " + paciente.getId());
            lblNombre.setText("Nombre: " + paciente.getNombre());
            lblApellidos.setText("Apellidos: " + paciente.getApellidos());
            lblFechaNacimiento.setText("Fecha de Nacimiento: " + paciente.getFecha_nacimiento());
            lblDireccion.setText("Dirección: " + paciente.getDireccion());
            lblTelefono.setText("Teléfono: " + paciente.getTelefono());
        }
    }
    
    private void mostrarDatos(Clases.Paciente paciente) {
        if (paciente != null) {
            lblID.setText("ID: " + paciente.getId());
            lblNombre.setText("Nombre: " + paciente.getNombre());
            lblApellidos.setText("Apellidos: " + paciente.getApellidos());
            lblFechaNacimiento.setText("Fecha de Nacimiento: " + paciente.getFecha_nacimiento());
            lblDireccion.setText("Dirección: " + paciente.getDireccion());
            lblTelefono.setText("Teléfono: " + paciente.getTelefono());
        }
    }
}
