package CRUDPaciente;
    import Clases.Paciente;
    import DAOs.DaoPaciente;
    import java.util.ArrayList;
    import javax.swing.JOptionPane;

public class AltasPaciente extends javax.swing.JFrame {

    private java.util.ArrayList<Paciente> pacientes;

    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblApellidos;
    private javax.swing.JLabel lblFechaNacimiento;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblTelefono;

    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnMostrar;

    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtFechaNacimiento;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtTelefono;


    public AltasPaciente() {
        pacientes = new java.util.ArrayList<>();
        super.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 420;
        d.width = 640;

        super.setSize(d);
        super.setTitle("ALTAS PACIENTES");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(229,204,255));

        lblId = new javax.swing.JLabel("ID:");
        lblId.setBounds(50, 20, 180, 30);

        lblNombre = new javax.swing.JLabel("Nombre:");
        lblNombre.setBounds(50, 50, 180, 30);

        lblApellidos = new javax.swing.JLabel("Apellidos:");
        lblApellidos.setBounds(50, 80, 180, 30);

        lblFechaNacimiento = new javax.swing.JLabel("Fecha Nacimiento:");
        lblFechaNacimiento.setBounds(50, 110, 180, 30);

        lblDireccion = new javax.swing.JLabel("Dirección:");
        lblDireccion.setBounds(50, 140, 180, 30);

        lblTelefono = new javax.swing.JLabel("Teléfono:");
        lblTelefono.setBounds(50, 170, 180, 30);

        txtId = new javax.swing.JTextField();
        txtId.setBounds(140, 20, 100, 30);

        txtNombre = new javax.swing.JTextField();
        txtNombre.setBounds(140, 50, 150, 30);

        txtApellidos = new javax.swing.JTextField();
        txtApellidos.setBounds(140, 80, 170, 30);

        txtFechaNacimiento = new javax.swing.JTextField();
        txtFechaNacimiento.setBounds(190, 110, 120, 30);

        txtDireccion = new javax.swing.JTextField();
        txtDireccion.setBounds(140, 140, 160, 30);

        txtTelefono = new javax.swing.JTextField();
        txtTelefono.setBounds(140, 170, 100, 30);

        btnGuardar = new javax.swing.JButton("Guardar");
        btnGuardar.setBounds(50, 230, 100, 40);
        btnGuardar.setBackground(new java.awt.Color(175, 238, 238));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnGuardar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGuardar.addActionListener((java.awt.event.ActionEvent e) -> {
            boolean datosIngresados = !txtId.getText().isEmpty() || !txtNombre.getText().isEmpty() || !txtApellidos.getText().isEmpty() || !txtFechaNacimiento.getText().isEmpty() || !txtDireccion.getText().isEmpty() || !txtTelefono.getText().isEmpty();

            if (!datosIngresados) {
                javax.swing.JOptionPane.showMessageDialog(this, "No se han ingresado datos para guardar.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (txtId.getText().isEmpty() || txtNombre.getText().isEmpty() || txtApellidos.getText().isEmpty() || txtFechaNacimiento.getText().isEmpty() || txtDireccion.getText().isEmpty() || txtTelefono.getText().isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Todos los campos deben ser llenados.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            int id = Integer.parseInt(txtId.getText());
            String nombre = txtNombre.getText();
            String apellidos = txtApellidos.getText();
            String fechaNacimiento = txtFechaNacimiento.getText();
            String direccion = txtDireccion.getText();
            String telefono = txtTelefono.getText();
            Paciente paciente = new Paciente(id, nombre, apellidos, fechaNacimiento, direccion, telefono);

            DaoPaciente daoPaciente = new DaoPaciente();
            daoPaciente.altasPaciente(paciente);
            JOptionPane.showMessageDialog(this, "Paciente Registrado");

            txtId.setText("");
            txtNombre.setText("");
            txtApellidos.setText("");
            txtFechaNacimiento.setText("");
            txtDireccion.setText("");
            txtTelefono.setText("");

        });

        btnMostrar = new javax.swing.JButton("Mostrar");
        btnMostrar.setBounds(160, 230, 100, 40);
        btnMostrar.setBackground(new java.awt.Color(175, 238, 238));
        btnMostrar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnMostrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnMostrar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();

            CRUDPaciente.MDPaciente vMySQL = new CRUDPaciente.MDPaciente();
            vMySQL.setVisible(true);
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(270, 230, 100, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();

            MenusOpciones.MPPaciente menuPrincipal = new MenusOpciones.MPPaciente();
            menuPrincipal.setVisible(true);
        });

        super.add(lblId);
        super.add(lblNombre);
        super.add(lblApellidos);
        super.add(lblFechaNacimiento);
        super.add(lblDireccion);
        super.add(lblTelefono);

        super.add(txtId);
        super.add(txtNombre);
        super.add(txtApellidos);
        super.add(txtFechaNacimiento);
        super.add(txtDireccion);
        super.add(txtTelefono);

        super.add(btnRegresar);
        super.add(btnGuardar);
        super.add(btnMostrar);
    }

}
