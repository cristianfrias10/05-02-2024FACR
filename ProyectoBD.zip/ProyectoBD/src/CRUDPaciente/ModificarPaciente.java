package CRUDPaciente;
    import DAOs.DaoPaciente;
    import Clases.Paciente;
    import java.awt.Color;
    import java.awt.Dimension;
    import java.awt.Toolkit;
    import java.awt.event.ActionEvent;
    import javax.swing.*;

public class ModificarPaciente extends JFrame {
    private java.util.ArrayList<Paciente> pacientes;
    private int indiceActual = 0;

    private JLabel lblTDatos;
    private JLabel lblId;
    private JLabel lblNombre;
    private JLabel lblApellidos;
    private JLabel lblFechaNacimiento;
    private JLabel lblDireccion;
    private JLabel lblTelefono;

    private JButton btnBuscar;
    private JButton btnModificar;
    private JButton btnRegresar;

    private JTextField txtModificar;
    private JTextField txtId;
    private JTextField txtNombre;
    private JTextField txtApellidos;
    private JTextField txtFechaNacimiento;
    private JTextField txtDireccion;
    private JTextField txtTelefono;

    public ModificarPaciente() {
        super.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 400;
        d.width = 640;

        super.setSize(d);
        super.setTitle("MODIFICAR PACIENTE");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(229,204,255));

        lblTDatos = new JLabel("INGRESA EL ID DEL PACIENTE A MODIFICAR:");
        lblTDatos.setBounds(50, 20, 350, 30);

        lblId = new JLabel("ID:");
        lblId.setBounds(50, 70, 180, 30);

        lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(50, 100, 180, 30);

        lblApellidos = new JLabel("Apellidos:");
        lblApellidos.setBounds(50, 130, 180, 30);

        lblFechaNacimiento = new JLabel("Fecha de Nacimiento:");
        lblFechaNacimiento.setBounds(50, 160, 180, 30);

        lblDireccion = new JLabel("Dirección:");
        lblDireccion.setBounds(50, 190, 180, 30);

        lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(50, 220, 180, 30);

        txtModificar = new JTextField();
        txtModificar.setBounds(370, 20, 100, 30);

        txtId = new JTextField();
        txtId.setBounds(250, 70, 100, 30);

        txtNombre = new JTextField();
        txtNombre.setBounds(250, 100, 150, 30);

        txtApellidos = new JTextField();
        txtApellidos.setBounds(250, 130, 170, 30);

        txtFechaNacimiento = new JTextField();
        txtFechaNacimiento.setBounds(250, 160, 150, 30);

        txtDireccion = new JTextField();
        txtDireccion.setBounds(250, 190, 170, 30);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(250, 220, 170, 30);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(480, 20, 100, 30);
        btnBuscar.setBackground(new Color(175, 238, 238));
        btnBuscar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((ActionEvent e) -> {
            String idBuscar = txtModificar.getText().trim();

            if (idBuscar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese un ID a buscar.");
            } else {
                int id = Integer.parseInt(idBuscar);
                DaoPaciente daoPaciente = new DaoPaciente();
                Paciente paciente = daoPaciente.buscarPaciente(id);

                if (paciente != null) {
                    mostrarDatos(paciente);
                } else {
                    JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                }

                txtModificar.setText("");
            }
        });

        btnModificar = new JButton("Modificar");
        btnModificar.setBounds(490, 100, 100, 40);
        btnModificar.setBackground(new Color(175, 238, 238));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnModificar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificar.addActionListener((ActionEvent e) -> {
            String idModificar = txtId.getText().trim();
            String nuevoNombre = txtNombre.getText().trim();
            String nuevosApellidos = txtApellidos.getText().trim();
            String nuevaFechaNacimiento = txtFechaNacimiento.getText().trim();
            String nuevaDireccion = txtDireccion.getText().trim();
            String nuevoTelefono = txtTelefono.getText().trim();

            if (idModificar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese el ID del paciente a modificar.");
                return;
            }

            int id = Integer.parseInt(idModificar);
            DaoPaciente daoPaciente = new DaoPaciente();
            Paciente pacienteModificar = daoPaciente.buscarPaciente(id);

            if (pacienteModificar == null) {
                JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                return;
            }

            if (!nuevoNombre.isEmpty()) {
                pacienteModificar.setNombre(nuevoNombre);
            }
            
            if (!nuevosApellidos.isEmpty()) {
                pacienteModificar.setApellidos(nuevosApellidos);
            }
            if (!nuevaFechaNacimiento.isEmpty()) {
                pacienteModificar.setFecha_nacimiento(nuevaFechaNacimiento);
            }
            if (!nuevaDireccion.isEmpty()) {
                pacienteModificar.setDireccion(nuevaDireccion);
            }
            if (!nuevoTelefono.isEmpty()) {
                pacienteModificar.setTelefono(nuevoTelefono);
            }

            try {
                daoPaciente.modificarPaciente(pacienteModificar);
                JOptionPane.showMessageDialog(this, "Datos del paciente modificados exitosamente.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error al modificar los datos del paciente: " + ex.getMessage());
            }

            limpiarCampos();
        });

        btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(490, 150, 100, 40);
        btnRegresar.setBackground(new Color(175, 238, 238));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((ActionEvent e) -> {
            this.dispose();

            MenusOpciones.MPPaciente menuPrincipal = new MenusOpciones.MPPaciente();
            menuPrincipal.setVisible(true);
        });

        super.add(lblTDatos);
        super.add(lblId);
        super.add(lblNombre);
        super.add(lblApellidos);
        super.add(lblFechaNacimiento);
        super.add(lblDireccion);
        super.add(lblTelefono);

        super.add(txtModificar);
        super.add(txtId);
        super.add(txtNombre);
        super.add(txtApellidos);
        super.add(txtFechaNacimiento);
        super.add(txtDireccion);
        super.add(txtTelefono);

        super.add(btnBuscar);
        super.add(btnModificar);
        super.add(btnRegresar);
    }

    private void mostrarDatos(Paciente paciente) {
        txtId.setText(String.valueOf(paciente.getId()));
        txtNombre.setText(paciente.getNombre());
        txtApellidos.setText(paciente.getApellidos());
        txtFechaNacimiento.setText(paciente.getFecha_nacimiento());
        txtDireccion.setText(paciente.getDireccion());
        txtTelefono.setText(paciente.getTelefono());
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtNombre.setText("");
        txtApellidos.setText("");
        txtFechaNacimiento.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
    }

    public static void main(String[] args) {
        new ModificarPaciente().setVisible(true);
    }
}
