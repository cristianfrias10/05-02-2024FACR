package ConexionMySQL;


public class Conexion {
    private java.sql.Connection cxn = null;
    private String url = "jdbc:mysql://localhost:3306/HospitalSystem";
    private String user = "root";
    private String password = "root";
    
    
    public java.sql.Connection getConexion(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cxn = java.sql.DriverManager.getConnection(url, user, password);
        } catch (Exception ex) {
            System.out.println("Error:" + ex.getMessage());
        }
        
        return cxn;
    }
    
    public void closeConexion(){
        if(cxn != null){
            try {
                cxn.close();
            } catch (java.sql.SQLException ex) {
                System.out.println("Error:" + ex.getMessage());
            }
        }
    }
    
}
