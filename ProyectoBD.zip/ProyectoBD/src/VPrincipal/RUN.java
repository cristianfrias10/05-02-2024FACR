package VPrincipal;


public class RUN {
    public static void main(String[] args) {
        VPrincipal.LoginFrame lf = new VPrincipal.LoginFrame();
        lf.setVisible(true);
    }   
}
