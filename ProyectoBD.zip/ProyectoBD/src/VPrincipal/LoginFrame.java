package VPrincipal;
    import Usuarios.UserDAO;
    import javax.swing.*;
    import java.awt.*;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private UserDAO userDAO;
    private JButton btnSalir;

    public LoginFrame() {
        userDAO = new UserDAO();

        setTitle("Sistema de Acceso");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new java.awt.Color(204, 204, 204));

        JLabel lbltitulo = new JLabel("SISTEMA DE ACCESO");
        lbltitulo.setBounds(200, 20, 200, 25);
        add(lbltitulo);
        
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(70, 70, 100, 25);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(160, 70, 200, 25);
        add(usernameField);

        JLabel passwordLabel = new JLabel("Contraseña:");
        passwordLabel.setBounds(70, 120, 100, 25);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(160, 120, 200, 25);
        add(passwordField);

        loginButton = new JButton("Acceder");
        loginButton.setBounds(160, 170, 100, 30);
        loginButton.addActionListener(new LoginButtonListener());
        add(loginButton);
        
        btnSalir = new JButton("Salir");
        btnSalir.setBounds(280, 170, 80, 30);
        btnSalir.addActionListener((java.awt.event.ActionEvent e) -> {
           this.dispose();
        });
        add(btnSalir);
    }

    private class LoginButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (userDAO.loginUser(username, password)) {
                JOptionPane.showMessageDialog(LoginFrame.this, "Acceso Permitido!");
                VPrincipal.V2 v2 = new VPrincipal.V2();
                v2.setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(LoginFrame.this, "Acceso Denegado! Intente de nuevo.");
            }
        }
    }
}


