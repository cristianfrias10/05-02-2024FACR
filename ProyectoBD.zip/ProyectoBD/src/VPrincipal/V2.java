package VPrincipal;


public class V2 extends javax.swing.JFrame  {
    private javax.swing.JButton btnBD;
    private javax.swing.JButton btnRegistros;
    private javax.swing.JButton btnRegresar;
    
    public V2() 
    {
        super.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 320;
        d.width = 640;
        
        super.setSize(d);
        super.setTitle("MENU PRINCIPAL");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(204,204, 204));
        
        btnBD = new javax.swing.JButton("Base de Datos");
        btnBD.setBounds(235, 50, 150, 40);
        btnBD.setBackground(new java.awt.Color(153,255,153));
        btnBD.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnBD.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBD.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            MenuPrincipal.MP mp = new MenuPrincipal.MP();
            mp.setVisible(true);
        });

        btnRegistros = new javax.swing.JButton("Dar Accesos");
        btnRegistros.setBounds(235, 100, 150, 40);
        btnRegistros.setBackground(new java.awt.Color(135,206,235));
        btnRegistros.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegistros.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegistros.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            MenuPrincipal.PermissionFrame pf = new MenuPrincipal.PermissionFrame();
            pf.setVisible(true);
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(260, 200, 100, 40);
        btnRegresar.setBackground(new java.awt.Color(192,192,192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            VPrincipal.LoginFrame lf = new VPrincipal.LoginFrame();
            lf.setVisible(true);
        });
        
        super.add(btnBD);
        super.add(btnRegistros);
        super.add(btnRegresar);
        
    }
}
