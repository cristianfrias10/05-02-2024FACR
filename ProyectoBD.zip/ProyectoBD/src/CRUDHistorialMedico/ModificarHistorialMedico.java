package CRUDHistorialMedico;
    import DAOs.DaoHistorialMedico;
    import Clases.HistorialMedico;
    import java.awt.Color;
    import java.awt.Dimension;
    import java.awt.Toolkit;
    import java.awt.event.ActionEvent;
    import javax.swing.*;

public class ModificarHistorialMedico extends JFrame {
    private java.util.ArrayList<HistorialMedico> historialesMedicos;
    
    private java.util.ArrayList<Clases.Paciente> pas;
    private java.util.ArrayList<Clases.Medico> med;

    private int indiceActual = 0;

    private JLabel lblTDatos;
    private JLabel lblId;
    private JLabel lblPacienteId;
    private JLabel lblMedicoId;
    private JLabel lblFechaRegistro;
    private JLabel lblDiagnostico;
    private JLabel lblTratamiento;

    private JButton btnBuscar;
    private JButton btnModificar;
    private JButton btnRegresar;

    private JTextField txtModificar;
    private JTextField txtId;
    private javax.swing.JComboBox<Integer> asignarPasiente;
    private javax.swing.JComboBox<Integer> asignarMedico;
    private JTextField txtFechaRegistro;
    private JTextField txtDiagnostico;
    private JTextField txtTratamiento;

    public ModificarHistorialMedico() {
        super.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 400;
        d.width = 640;

        super.setSize(d);
        super.setTitle("MODIFICAR HISTORIAL MÉDICO");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(255,245,238));

        lblTDatos = new JLabel("INGRESA EL ID DEL HISTORIAL MÉDICO A MODIFICAR:");
        lblTDatos.setBounds(50, 20, 350, 30);

        lblId = new JLabel("ID:");
        lblId.setBounds(50, 70, 180, 30);

        lblPacienteId = new JLabel("Paciente ID:");
        lblPacienteId.setBounds(50, 100, 180, 30);

        lblMedicoId = new JLabel("Médico ID:");
        lblMedicoId.setBounds(50, 130, 180, 30);

        lblFechaRegistro = new JLabel("Fecha Registro:");
        lblFechaRegistro.setBounds(50, 160, 180, 30);

        lblDiagnostico = new JLabel("Diagnóstico:");
        lblDiagnostico.setBounds(50, 190, 180, 30);

        lblTratamiento = new JLabel("Tratamiento:");
        lblTratamiento.setBounds(50, 220, 180, 30);

        txtModificar = new JTextField();
        txtModificar.setBounds(370, 20, 100, 30);

        txtId = new JTextField();
        txtId.setBounds(250, 70, 100, 30);

        asignarPasiente = new javax.swing.JComboBox<>();
        asignarPasiente.setBounds(250, 100, 150, 30);
        asignarPasiente.setModel(new javax.swing.DefaultComboBoxModel<>(new Integer[] {1, 2, 3, 4}));

        asignarMedico = new javax.swing.JComboBox<>();
        asignarMedico.setBounds(250, 130, 170, 30);
        asignarMedico .setModel(new javax.swing.DefaultComboBoxModel<>(new Integer[] {1, 2, 3, 4}));

        txtFechaRegistro = new JTextField();
        txtFechaRegistro.setBounds(250, 160, 150, 30);

        txtDiagnostico = new JTextField();
        txtDiagnostico.setBounds(250, 190, 170, 30);

        txtTratamiento = new JTextField();
        txtTratamiento.setBounds(250, 220, 170, 30);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(480, 20, 100, 30);
        btnBuscar.setBackground(new Color(175,238,238));
        btnBuscar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((ActionEvent e) -> {
            String idBuscar = txtModificar.getText().trim();

            if (idBuscar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese un ID a buscar.");
            } else {
                int id = Integer.parseInt(idBuscar);
                DaoHistorialMedico daoHistorialMedico = new DaoHistorialMedico();
                HistorialMedico historialMedico = daoHistorialMedico.buscarHistorialMedico(id);

                if (historialMedico != null) {
                    mostrarDatos(historialMedico);
                } else {
                    JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                }

                txtModificar.setText("");
            }
        });

        btnModificar = new JButton("Modificar");
        btnModificar.setBounds(490, 100, 100, 40);
        btnModificar.setBackground(new Color(175,238,238));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnModificar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificar.addActionListener((ActionEvent e) -> {
            String idModificar = txtId.getText().trim();
            Integer nuevoPacienteId = (Integer) asignarPasiente.getSelectedItem();
            Integer nuevoMedicoId = (Integer) asignarMedico.getSelectedItem();
            String nuevaFechaRegistro = txtFechaRegistro.getText().trim();
            String nuevoDiagnostico = txtDiagnostico.getText().trim();
            String nuevoTratamiento = txtTratamiento.getText().trim();

            if (idModificar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese el ID del historial médico a modificar.");
                return;
            }

            int id = Integer.parseInt(idModificar);
            DaoHistorialMedico daoHistorialMedico = new DaoHistorialMedico();
            HistorialMedico historialMedicoModificar = daoHistorialMedico.buscarHistorialMedico(id);

            if (historialMedicoModificar == null) {
                JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                return;
            }

            if (nuevoPacienteId != null && nuevoPacienteId != 0) {
                historialMedicoModificar.setPaciente_id(nuevoPacienteId);
            }
            if (nuevoMedicoId != null && nuevoMedicoId != 0) {
                historialMedicoModificar.setMedico_id(nuevoMedicoId);
            }
            if (!nuevaFechaRegistro.isEmpty()) {
                historialMedicoModificar.setFecha_registro(nuevaFechaRegistro);
            }
            if (!nuevoDiagnostico.isEmpty()) {
                historialMedicoModificar.setDiagnostico(nuevoDiagnostico);
            }
            if (!nuevoTratamiento.isEmpty()) {
                historialMedicoModificar.setTratamiento(nuevoTratamiento);
            }

            daoHistorialMedico.modificarHistorialMedico(historialMedicoModificar);

            JOptionPane.showMessageDialog(this, "Los datos se han modificado correctamente.");

            txtId.setText("");
            txtFechaRegistro.setText("");
            txtDiagnostico.setText("");
            txtTratamiento.setText("");
        });

        btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(490, 150, 100, 40);
        btnRegresar.setBackground(new Color(192,192,192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((ActionEvent e) -> {
            this.dispose();
            
            MenusOpciones.MPHistorialMedico menuPrincipal = new MenusOpciones.MPHistorialMedico();
            menuPrincipal.setVisible(true);
        });

        super.add(lblTDatos);
        super.add(lblId);
        super.add(lblPacienteId);
        super.add(lblMedicoId);
        super.add(lblFechaRegistro);
        super.add(lblDiagnostico);
        super.add(lblTratamiento);

        super.add(btnBuscar);
        super.add(btnModificar);
        super.add(btnRegresar);

        super.add(txtModificar);
        super.add(txtId);
        super.add(asignarMedico);
        super.add(asignarPasiente);
        super.add(txtFechaRegistro);
        super.add(txtDiagnostico);
        super.add(txtTratamiento);

        mostrarDatos(indiceActual);
        
        cargarDatosPasiente();
        cargarDatosMedico();
    }

    private void mostrarDatos(int index) {
        DaoHistorialMedico daoHistorialMedico = new DaoHistorialMedico();
        historialesMedicos = daoHistorialMedico.obtenerTodosHistorialesMedicos();

        if (index >= 0 && index < historialesMedicos.size()) {
            HistorialMedico historialMedico = historialesMedicos.get(index);
            lblId.setText("ID: " + historialMedico.getId());
            lblPacienteId.setText("Paciente ID: " + historialMedico.getPaciente_id());
            lblMedicoId.setText("Médico ID: " + historialMedico.getMedico_id());
            lblFechaRegistro.setText("Fecha Registro: " + historialMedico.getFecha_registro());
            lblDiagnostico.setText("Diagnóstico: " + historialMedico.getDiagnostico());
            lblTratamiento.setText("Tratamiento: " + historialMedico.getTratamiento());
        }
    }

    private void mostrarDatos(HistorialMedico historialMedico) {
        if (historialMedico != null) {
            lblId.setText("ID: " + historialMedico.getId());
            lblPacienteId.setText("Paciente ID: " + historialMedico.getPaciente_id());
            lblMedicoId.setText("Médico ID: " + historialMedico.getMedico_id());
            lblFechaRegistro.setText("Fecha Registro: " + historialMedico.getFecha_registro());
            lblDiagnostico.setText("Diagnóstico: " + historialMedico.getDiagnostico());
            lblTratamiento.setText("Tratamiento: " + historialMedico.getTratamiento());
        }
    }
    
    private void cargarDatosPasiente() {
        DAOs.DaoPaciente daoPasiente = new DAOs.DaoPaciente();
        pas = daoPasiente.obtenerTodosPacientes();
        
        llenarComboBoxPasientes();
    }
    
    private void llenarComboBoxPasientes() {
        asignarPasiente.removeAllItems();

        for (Clases.Paciente pasientes : pas) {
            asignarPasiente.addItem(pasientes.getId());
        }
    }
    
    private void cargarDatosMedico() {
        DAOs.DaoMedico daoMedico = new DAOs.DaoMedico();
        med = daoMedico.obtenerTodosMedicos();
        
        llenarComboBoxMedicos();
    }
    
    private void llenarComboBoxMedicos() {
        asignarMedico.removeAllItems();

        for (Clases.Medico medicos : med) {
            asignarMedico.addItem(medicos.getId());
        }
    }
}
