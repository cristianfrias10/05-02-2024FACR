package CRUDHistorialMedico;
    import Clases.HistorialMedico;
    import DAOs.DaoHistorialMedico;
    import java.util.ArrayList;

public class BajasHistorialMedico extends javax.swing.JFrame {
    private java.util.ArrayList<HistorialMedico> historialesMedicos;

    private int indiceActual = 0;
    
    private javax.swing.JLabel lblElegir;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblPacienteID;
    private javax.swing.JLabel lblMedicoID;
    private javax.swing.JLabel lblFechaRegistro;
    private javax.swing.JLabel lblDiagnostico;
    private javax.swing.JLabel lblTratamiento;

    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnRegresar;

    private javax.swing.JTextField txtID;

    public BajasHistorialMedico() {
        initComponents();
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 320;
        d.width = 640;
        
        super.setSize(d);
        setTitle("BAJAS HISTORIALES MÉDICOS");
        setLayout(null);
        getContentPane().setBackground(new java.awt.Color(255,245,238));

        lblElegir = new javax.swing.JLabel("ID del Historial Médico:");
        lblElegir.setBounds(50, 20, 180, 30);

        lblID = new javax.swing.JLabel("ID:");
        lblID.setBounds(50, 80, 180, 30);

        lblPacienteID = new javax.swing.JLabel("Paciente ID:");
        lblPacienteID.setBounds(50, 110, 180, 30);

        lblMedicoID = new javax.swing.JLabel("Médico ID:");
        lblMedicoID.setBounds(50, 140, 180, 30);

        lblFechaRegistro = new javax.swing.JLabel("Fecha de Registro:");
        lblFechaRegistro.setBounds(50, 170, 180, 30);

        lblDiagnostico = new javax.swing.JLabel("Diagnóstico:");
        lblDiagnostico.setBounds(50, 200, 180, 30);

        lblTratamiento = new javax.swing.JLabel("Tratamiento:");
        lblTratamiento.setBounds(50, 230, 180, 30);

        btnBorrar = new javax.swing.JButton("Dar de Baja");
        btnBorrar.setBounds(250, 230, 130, 40);
        btnBorrar.setBackground(new java.awt.Color(175, 238, 238));
        btnBorrar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnBorrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBorrar.addActionListener((java.awt.event.ActionEvent e) -> {
            DaoHistorialMedico daoHistorialMedico = new DaoHistorialMedico();
            String idText = txtID.getText();

            try {
                int id = Integer.parseInt(idText);
                HistorialMedico historialMedicoBorrar = daoHistorialMedico.buscarHistorialMedico(id);

                if (historialMedicoBorrar != null) {
                    daoHistorialMedico.bajasHistorialMedico(id);
                    javax.swing.JOptionPane.showMessageDialog(this, "Historial médico borrado exitosamente.");

                    mostrarDatos(historialMedicoBorrar); // Actualizar la vista con los datos borrados
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "Historial médico no encontrado.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID del historial médico.");
            }
            txtID.setText("");
        });

        btnBuscar = new javax.swing.JButton("Buscar");
        btnBuscar.setBounds(280, 20, 100, 30);
        btnBuscar.setBackground(new java.awt.Color(175, 238, 238));
        btnBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((java.awt.event.ActionEvent e) -> {
            DaoHistorialMedico daoHistorialMedico = new DaoHistorialMedico();
            String idText = txtID.getText();

            try {
                int id = Integer.parseInt(idText);
                HistorialMedico historialMedico = daoHistorialMedico.buscarHistorialMedico(id);

                if (historialMedico != null) {
                    mostrarDatos(historialMedico);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "Historial médico no encontrado.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID del historial médico.");
            }
            txtID.setText("");
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(410, 230, 130, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            MenusOpciones.MPHistorialMedico menuPrincipal = new MenusOpciones.MPHistorialMedico();
            menuPrincipal.setVisible(true);
        });

        txtID = new javax.swing.JTextField();
        txtID.setBounds(220, 20, 60, 30);

        add(lblElegir);
        add(lblID);
        add(lblPacienteID);
        add(lblMedicoID);
        add(lblFechaRegistro);
        add(lblDiagnostico);
        add(lblTratamiento);
        add(btnBorrar);
        add(btnBuscar);
        add(btnRegresar);
        add(txtID);
    }

    private void mostrarDatos(int index) {
        DaoHistorialMedico daoHistorialMedico = new DaoHistorialMedico();
        historialesMedicos = daoHistorialMedico.obtenerTodosHistorialesMedicos();

        if (index >= 0 && index < historialesMedicos.size()) {
            HistorialMedico historialMedico = historialesMedicos.get(index);
            lblID.setText("ID: " + historialMedico.getId());
            lblPacienteID.setText("Paciente ID: " + historialMedico.getPaciente_id());
            lblMedicoID.setText("Médico ID: " + historialMedico.getMedico_id());
            lblFechaRegistro.setText("Fecha Registro: " + historialMedico.getFecha_registro());
            lblDiagnostico.setText("Diagnóstico: " + historialMedico.getDiagnostico());
            lblTratamiento.setText("Tratamiento: " + historialMedico.getTratamiento());
        }
    }

    private void mostrarDatos(HistorialMedico historialMedico) {
        if (historialMedico != null) {
            lblID.setText("ID: " + historialMedico.getId());
            lblPacienteID.setText("Paciente ID: " + historialMedico.getPaciente_id());
            lblMedicoID.setText("Médico ID: " + historialMedico.getMedico_id());
            lblFechaRegistro.setText("Fecha Registro: " + historialMedico.getFecha_registro());
            lblDiagnostico.setText("Diagnóstico: " + historialMedico.getDiagnostico());
            lblTratamiento.setText("Tratamiento: " + historialMedico.getTratamiento());
        }
    }
}