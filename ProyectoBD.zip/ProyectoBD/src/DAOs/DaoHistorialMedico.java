package DAOs;
    import Clases.HistorialMedico;
    import java.sql.SQLException;
    import java.util.ArrayList;
    import java.util.logging.Level;
    import java.util.logging.Logger;

public class DaoHistorialMedico implements IDAOs.IDaoHistorialMedico {

    private java.sql.Connection cxn = null;

    @Override
    public void altasHistorialMedico(HistorialMedico historialMedico) {
        // Guardar datos en un Archivo
        // saveArchivos(historialMedico);

        // Guardar datos en MySQL
        try {
            saveMySQL(historialMedico);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void bajasHistorialMedico(int id) {
        // Borrar datos en un Archivo
        // deleteArchivos(id);

        // Borrar datos en MySQL
        try {
            deleteMySQL(id);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void modificarHistorialMedico(HistorialMedico historialMedicoModificado) {
        // Modificar los datos de un Archivo
        // modifyArchivos(historialMedicoModificado);

        // Modificar los datos de MySQL
        try {
            modifyMySQL(historialMedicoModificado);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public ArrayList<HistorialMedico> obtenerTodosHistorialesMedicos() {
        ArrayList<HistorialMedico> historialesMedicos = new ArrayList<>();

        // Obtener los datos del Archivo
        // historialesMedicos = readArchivos();
        // Obtener los datos de MySQL
        try {
            historialesMedicos = readMySQL();
        } catch (SQLException ex) {
            Logger.getLogger(DaoHistorialMedico.class.getName()).log(Level.SEVERE, "Error al intentar leer los datos de MySQL", ex);
        }

        return historialesMedicos;
    }

    @Override
    public HistorialMedico buscarHistorialMedico(int id) {
        ArrayList<HistorialMedico> historialesMedicos;
        historialesMedicos = obtenerTodosHistorialesMedicos();

        for (HistorialMedico historialMedico : historialesMedicos) {
            if (historialMedico.getId() == id) {
                return historialMedico;
            }
        }
        return null;
    }

    @Override
    public void guardarHistorialesMedicos(ArrayList<HistorialMedico> historialesMedicos) {
        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream("HistorialesMedicos");
            java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(fos);
            oos.writeObject(historialesMedicos);
            oos.close();
        } catch (java.io.IOException ex) {
            System.out.println("Error al guardar en el archivo: " + ex.toString());
        }
    }

    private void saveArchivos(HistorialMedico historialMedico) {
        ArrayList<HistorialMedico> historialesMedicos;
        historialesMedicos = obtenerTodosHistorialesMedicos();
        historialesMedicos.add(historialMedico);
        guardarHistorialesMedicos(historialesMedicos);
    }

    private void deleteArchivos(int id) {
        ArrayList<HistorialMedico> historialesMedicos;
        historialesMedicos = obtenerTodosHistorialesMedicos();

        for (int i = 0; i < historialesMedicos.size(); i++) {
            if (historialesMedicos.get(i).getId() == id) {
                historialesMedicos.remove(i);
                break;
            }
        }

        guardarHistorialesMedicos(historialesMedicos);
    }

    private void modifyArchivos(HistorialMedico historialMedicoModificado) {
        ArrayList<HistorialMedico> historialesMedicos;
        historialesMedicos = obtenerTodosHistorialesMedicos();

        for (int i = 0; i < historialesMedicos.size(); i++) {
            if (historialesMedicos.get(i).getId() == historialMedicoModificado.getId()) {
                historialesMedicos.set(i, historialMedicoModificado);
                break;
            }
        }

        guardarHistorialesMedicos(historialesMedicos);
    }

    private ArrayList<HistorialMedico> readArchivos() {
        ArrayList<HistorialMedico> historialesMedicos = new ArrayList<>();

        try {
            java.io.FileInputStream fis = new java.io.FileInputStream("HistorialesMedicos");
            java.io.ObjectInputStream ois = new java.io.ObjectInputStream(fis);
            historialesMedicos = (ArrayList<HistorialMedico>) ois.readObject();
            ois.close();
        } catch (java.io.IOException | ClassNotFoundException ex) {
            // Si ocurre un error al leer el archivo, se muestra el mensaje de error
            System.out.println("Error al leer el archivo de historiales médicos: " + ex.getMessage());
        }

        return historialesMedicos;
    }

    private void saveMySQL(HistorialMedico historialMedico) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "INSERT INTO Historial_Medico(id, paciente_id, medico_id, fecha_registro, diagnostico, tratamiento) VALUES(?, ?, ?, ?, ?, ?)";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, historialMedico.getId());
        ps.setInt(2, historialMedico.getPaciente_id());
        ps.setInt(3, historialMedico.getMedico_id());
        ps.setString(4, historialMedico.getFecha_registro());
        ps.setString(5, historialMedico.getDiagnostico());
        ps.setString(6, historialMedico.getTratamiento());
        ps.executeUpdate();

        con.closeConexion();
    }

    private void deleteMySQL(int id) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "DELETE FROM Historial_Medico WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, id);
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Historial médico con ID " + id + " eliminado correctamente.");
        } else {
            System.out.println("No se encontró el historial médico con ID: " + id);
        }

        con.closeConexion();
    }

    private void modifyMySQL(HistorialMedico historialMedicoModificado) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "UPDATE Historial_Medico SET paciente_id = ?, medico_id = ?, fecha_registro = ?, diagnostico = ?, tratamiento = ? WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, historialMedicoModificado.getPaciente_id());
        ps.setInt(2, historialMedicoModificado.getMedico_id());
        ps.setString(3, historialMedicoModificado.getFecha_registro());
        ps.setString(4, historialMedicoModificado.getDiagnostico());
        ps.setString(5, historialMedicoModificado.getTratamiento());
        ps.setInt(6, historialMedicoModificado.getId());
        ps.executeUpdate();

        con.closeConexion();
    }

    private ArrayList<HistorialMedico> readMySQL() throws SQLException {
        ArrayList<HistorialMedico> historialesMedicos = new ArrayList<>();
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "SELECT * FROM Historial_Medico";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        java.sql.ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            HistorialMedico historialMedico = new HistorialMedico(
                    rs.getInt("id"),
                    rs.getInt("paciente_id"),
                    rs.getInt("medico_id"),
                    rs.getString("fecha_registro"),
                    rs.getString("diagnostico"),
                    rs.getString("tratamiento")
            );
            historialesMedicos.add(historialMedico);
        }

        con.closeConexion();
        return historialesMedicos;
    }
}
