package DAOs;
    import Clases.Cita;
    import java.sql.SQLException;
    import java.util.ArrayList;
    import java.util.logging.Level;
    import java.util.logging.Logger;

public class DaoCita implements IDAOs.IDaoCita {

    private java.sql.Connection cxn = null;

    @Override
    public void altasCita(Cita cita) {
        // Guardar datos en un Archivo
        // saveArchivos(cita);

        // Guardar datos en MySQL
        try {
            saveMySQL(cita);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void bajasCita(int id) {
        // Borrar datos en un Archivo
        // deleteArchivos(id);

        // Borrar datos en MySQL
        try {
            deleteMySQL(id);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void modificarCita(Cita citaModificada) {
        // Modificar los datos de un Archivo
        // modifyArchivos(citaModificada);

        // Modificar los datos de MySQL
        try {
            modifyMySQL(citaModificada);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public ArrayList<Cita> obtenerTodasCitas() {
        ArrayList<Cita> citas = new ArrayList<>();

        // Obtener los datos del Archivo
        // citas = readArchivos();

        // Obtener los datos de MySQL
        try {
            citas = readMySQL();
        } catch (SQLException ex) {
            Logger.getLogger(DaoCita.class.getName()).log(Level.SEVERE, "Error al intentar leer los datos de MySQL", ex);
        }

        return citas;
    }

    @Override
    public Cita buscarCita(int id) {
        ArrayList<Cita> citas;
        citas = obtenerTodasCitas();

        for (Cita cita : citas) {
            if (cita.getId() == id) {
                return cita;
            }
        }
        return null;
    }

    @Override
    public void guardarCitas(ArrayList<Cita> citas) {
        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream("Citas");
            java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(fos);
            oos.writeObject(citas);
            oos.close();
        } catch (java.io.IOException ex) {
            System.out.println("Error al guardar en el archivo: " + ex.toString());
        }
    }

    private void saveArchivos(Cita cita) {
        ArrayList<Cita> citas;
        citas = obtenerTodasCitas();
        citas.add(cita);
        guardarCitas(citas);
    }

    private void deleteArchivos(int id) {
        ArrayList<Cita> citas;
        citas = obtenerTodasCitas();

        for (int i = 0; i < citas.size(); i++) {
            if (citas.get(i).getId() == id) {
                citas.remove(i);
                break;
            }
        }

        guardarCitas(citas);
    }

    private void modifyArchivos(Cita citaModificada) {
        ArrayList<Cita> citas;
        citas = obtenerTodasCitas();

        for (int i = 0; i < citas.size(); i++) {
            if (citas.get(i).getId() == citaModificada.getId()) {
                citas.set(i, citaModificada);
                break;
            }
        }

        guardarCitas(citas);
    }

    private ArrayList<Cita> readArchivos() {
        ArrayList<Cita> citas = new ArrayList<>();

        try {
            java.io.FileInputStream fis = new java.io.FileInputStream("Citas");
            java.io.ObjectInputStream ois = new java.io.ObjectInputStream(fis);
            citas = (ArrayList<Cita>) ois.readObject();
            ois.close();
        } catch (java.io.IOException | ClassNotFoundException ex) {
            // Si ocurre un error al leer el archivo, se muestra el mensaje de error
            System.out.println("Error al leer el archivo de citas: " + ex.getMessage());
        }

        return citas;
    }

    private void saveMySQL(Cita cita) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "INSERT INTO Cita(id, paciente_id, medico_id, fecha_cita, hora_cita) VALUES(?, ?, ?, ?, ?)";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, cita.getId());
        ps.setInt(2, cita.getPaciente_id());
        ps.setInt(3, cita.getMedico_id());
        ps.setString(4, cita.getFecha_cita());
        ps.setString(5, cita.getHora_cita());
        ps.executeUpdate();

        con.closeConexion();
    }

    private void deleteMySQL(int id) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "DELETE FROM Cita WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, id);
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Cita con ID " + id + " eliminada correctamente.");
        } else {
            System.out.println("No se encontró la cita con ID: " + id);
        }

        con.closeConexion();
    }

    private void modifyMySQL(Cita citaModificada) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "UPDATE Cita SET paciente_id = ?, medico_id = ?, fecha_cita = ?, hora_cita = ? WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, citaModificada.getPaciente_id());
        ps.setInt(2, citaModificada.getMedico_id());
        ps.setString(3, citaModificada.getFecha_cita());
        ps.setString(4, citaModificada.getHora_cita());
        ps.setInt(5, citaModificada.getId());
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Cita con ID " + citaModificada.getId() + " modificada correctamente.");
        } else {
            System.out.println("No se encontró la cita con ID " + citaModificada.getId());
        }

        con.closeConexion();
    }

    private ArrayList<Cita> readMySQL() throws SQLException {
        ArrayList<Cita> citas;
        citas = new ArrayList<>();

        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "SELECT * FROM Cita";
        try (java.sql.PreparedStatement ps = cxn.prepareStatement(sql);
             java.sql.ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                int paciente_id = rs.getInt("paciente_id");
                int medico_id = rs.getInt("medico_id");
                String fecha_cita = rs.getString("fecha_cita");
                String hora_cita = rs.getString("hora_cita");
                Cita cita = new Cita(id, paciente_id, medico_id, fecha_cita, hora_cita);
                citas.add(cita);
            }
        } catch (SQLException ex) {
            System.out.println("Error al intentar leer los datos de MySQL: " + ex.getMessage());
        }

        con.closeConexion();
        return citas;
    }
}

