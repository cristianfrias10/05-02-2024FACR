package DAOs;
    import Clases.Habitacion;
    import java.sql.SQLException;
    import java.util.ArrayList;
    import java.util.logging.Level;
    import java.util.logging.Logger;

public class DaoHabitacion implements IDAOs.IDaoHabitacion {

    private java.sql.Connection cxn = null;

    @Override
    public void altasHabitacion(Habitacion habitacion) {
        // Guardar datos en un Archivo
        // saveArchivos(habitacion);

        // Guardar datos en MySQL
        try {
            saveMySQL(habitacion);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void bajasHabitacion(int id) {
        // Borrar datos en un Archivo
        // deleteArchivos(id);

        // Borrar datos en MySQL
        try {
            deleteMySQL(id);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void modificarHabitacion(Habitacion habitacionModificada) {
        // Modificar los datos de un Archivo
        // modifyArchivos(habitacionModificada);

        // Modificar los datos de MySQL
        try {
            modifyMySQL(habitacionModificada);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public ArrayList<Habitacion> obtenerTodasHabitaciones() {
        ArrayList<Habitacion> habitaciones = new ArrayList<>();

        // Obtener los datos del Archivo
        // habitaciones = readArchivos();

        // Obtener los datos de MySQL
        try {
            habitaciones = readMySQL();
        } catch (SQLException ex) {
            Logger.getLogger(DaoHabitacion.class.getName()).log(Level.SEVERE, "Error al intentar leer los datos de MySQL", ex);
        }

        return habitaciones;
    }

    @Override
    public Habitacion buscarHabitacion(int id) {
        ArrayList<Habitacion> habitaciones;
        habitaciones = obtenerTodasHabitaciones();

        for (Habitacion habitacion : habitaciones) {
            if (habitacion.getId() == id) {
                return habitacion;
            }
        }
        return null;
    }

    @Override
    public void guardarHabitaciones(ArrayList<Habitacion> habitaciones) {
        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream("Habitaciones");
            java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(fos);
            oos.writeObject(habitaciones);
            oos.close();
        } catch (java.io.IOException ex) {
            System.out.println("Error al guardar en el archivo: " + ex.toString());
        }
    }

    private void saveArchivos(Habitacion habitacion) {
        ArrayList<Habitacion> habitaciones;
        habitaciones = obtenerTodasHabitaciones();
        habitaciones.add(habitacion);
        guardarHabitaciones(habitaciones);
    }

    private void deleteArchivos(int id) {
        ArrayList<Habitacion> habitaciones;
        habitaciones = obtenerTodasHabitaciones();

        for (int i = 0; i < habitaciones.size(); i++) {
            if (habitaciones.get(i).getId() == id) {
                habitaciones.remove(i);
                break;
            }
        }

        guardarHabitaciones(habitaciones);
    }

    private void modifyArchivos(Habitacion habitacionModificada) {
        ArrayList<Habitacion> habitaciones;
        habitaciones = obtenerTodasHabitaciones();

        for (int i = 0; i < habitaciones.size(); i++) {
            if (habitaciones.get(i).getId() == habitacionModificada.getId()) {
                habitaciones.set(i, habitacionModificada);
                break;
            }
        }

        guardarHabitaciones(habitaciones);
    }

    private ArrayList<Habitacion> readArchivos() {
        ArrayList<Habitacion> habitaciones = new ArrayList<>();

        try {
            java.io.FileInputStream fis = new java.io.FileInputStream("Habitaciones");
            java.io.ObjectInputStream ois = new java.io.ObjectInputStream(fis);
            habitaciones = (ArrayList<Habitacion>) ois.readObject();
            ois.close();
        } catch (java.io.IOException | ClassNotFoundException ex) {
            // Si ocurre un error al leer el archivo, se muestra el mensaje de error
            System.out.println("Error al leer el archivo de habitaciones: " + ex.getMessage());
        }

        return habitaciones;
    }

    private void saveMySQL(Habitacion habitacion) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "INSERT INTO Habitacion(id, numero, tipo, estado) VALUES(?, ?, ?, ?)";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, habitacion.getId());
        ps.setString(2, habitacion.getNumero());
        ps.setString(3, habitacion.getTipo());
        ps.setString(4, habitacion.getEstado());
        ps.executeUpdate();

        con.closeConexion();
    }

    private void deleteMySQL(int id) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "DELETE FROM Habitacion WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, id);
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Habitacion con ID " + id + " eliminada correctamente.");
        } else {
            System.out.println("No se encontró la habitacion con ID: " + id);
        }

        con.closeConexion();
    }

    private void modifyMySQL(Habitacion habitacionModificada) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "UPDATE Habitacion SET numero = ?, tipo = ?, estado = ? WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setString(1, habitacionModificada.getNumero());
        ps.setString(2, habitacionModificada.getTipo());
        ps.setString(3, habitacionModificada.getEstado());
        ps.setInt(4, habitacionModificada.getId());
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Habitacion con ID " + habitacionModificada.getId() + " modificada correctamente.");
        } else {
            System.out.println("No se encontró la habitacion con ID " + habitacionModificada.getId());
        }

        con.closeConexion();
    }

    private ArrayList<Habitacion> readMySQL() throws SQLException {
        ArrayList<Habitacion> habitaciones;
        habitaciones = new ArrayList<>();

        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "SELECT * FROM Habitacion";
        try (java.sql.PreparedStatement ps = cxn.prepareStatement(sql);
             java.sql.ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String numero = rs.getString("numero");
                String tipo = rs.getString("tipo");
                String estado = rs.getString("estado");
                Habitacion habitacion = new Habitacion(id, numero, tipo, estado);
                habitaciones.add(habitacion);
            }
        } catch (SQLException ex) {
            System.out.println("Error al intentar leer los datos de MySQL: " + ex.getMessage());
        }

        con.closeConexion();
        return habitaciones;
    }
}
