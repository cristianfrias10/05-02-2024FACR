package DAOs;
    import Clases.Medico;
    import java.sql.SQLException;
    import java.util.ArrayList;
    import java.util.logging.Level;
    import java.util.logging.Logger;

public class DaoMedico implements IDAOs.IDaoMedico {

    private java.sql.Connection cxn = null;

    @Override
    public void altasMedico(Medico medico) {
        // Guardar datos en un Archivo
        // saveArchivos(medico);

        // Guardar datos en MySQL
        try {
            saveMySQL(medico);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void bajasMedico(int id) {
        // Borrar datos en un Archivo
        // deleteArchivos(id);

        // Borrar datos en MySQL
        try {
            deleteMySQL(id);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void modificarMedico(Medico medicoModificado) {
        // Modificar los datos de un Archivo
        // modifyArchivos(medicoModificado);

        // Modificar los datos de MySQL
        try {
            modifyMySQL(medicoModificado);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public ArrayList<Medico> obtenerTodosMedicos() {
        ArrayList<Medico> medicos = new ArrayList<>();

        // Obtener los datos del Archivo
        // medicos = readArchivos();
        // Obtener los datos de MySQL
        try {
            medicos = readMySQL();
        } catch (SQLException ex) {
            Logger.getLogger(DaoMedico.class.getName()).log(Level.SEVERE, "Error al intentar leer los datos de MySQL", ex);
        }

        return medicos;
    }

    @Override
    public Medico buscarMedico(int id) {
        ArrayList<Medico> medicos;
        medicos = obtenerTodosMedicos();

        for (Medico medico : medicos) {
            if (medico.getId() == id) {
                return medico;
            }
        }
        return null;
    }

    @Override
    public void guardarMedicos(ArrayList<Medico> medicos) {
        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream("Medicos");
            java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(fos);
            oos.writeObject(medicos);
            oos.close();
        } catch (java.io.IOException ex) {
            System.out.println("Error al guardar en el archivo: " + ex.toString());
        }
    }

    private void saveArchivos(Medico medico) {
        ArrayList<Medico> medicos;
        medicos = obtenerTodosMedicos();
        medicos.add(medico);
        guardarMedicos(medicos);
    }

    private void deleteArchivos(int id) {
        ArrayList<Medico> medicos;
        medicos = obtenerTodosMedicos();

        for (int i = 0; i < medicos.size(); i++) {
            if (medicos.get(i).getId() == id) {
                medicos.remove(i);
                break;
            }
        }

        guardarMedicos(medicos);
    }

    private void modifyArchivos(Medico medicoModificado) {
        ArrayList<Medico> medicos;
        medicos = obtenerTodosMedicos();

        for (int i = 0; i < medicos.size(); i++) {
            if (medicos.get(i).getId() == medicoModificado.getId()) {
                medicos.set(i, medicoModificado);
                break;
            }
        }

        guardarMedicos(medicos);
    }

    private ArrayList<Medico> readArchivos() {
        ArrayList<Medico> medicos = new ArrayList<>();

        try {
            java.io.FileInputStream fis = new java.io.FileInputStream("Medicos");
            java.io.ObjectInputStream ois = new java.io.ObjectInputStream(fis);
            medicos = (ArrayList<Medico>) ois.readObject();
            ois.close();
        } catch (java.io.IOException | ClassNotFoundException ex) {
            // Si ocurre un error al leer el archivo, se muestra el mensaje de error
            System.out.println("Error al leer el archivo de medicos: " + ex.getMessage());
        }

        return medicos;
    }

    private void saveMySQL(Medico medico) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "INSERT INTO Medico(id, nombre, apellidos, especialidad, telefono) VALUES(?, ?, ?, ?, ?)";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, medico.getId());
        ps.setString(2, medico.getNombre());
        ps.setString(3, medico.getApellidos());
        ps.setString(4, medico.getEspecialidad());
        ps.setString(5, medico.getTelefono());
        ps.executeUpdate();

        con.closeConexion();
    }

    private void deleteMySQL(int id) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "DELETE FROM Medico WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, id);
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Médico con ID " + id + " eliminado correctamente.");
        } else {
            System.out.println("No se encontró el médico con ID: " + id);
        }

        con.closeConexion();
    }

    private void modifyMySQL(Medico medicoModificado) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "UPDATE Medico SET nombre = ?, apellidos = ?, especialidad = ?, telefono = ? WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setString(1, medicoModificado.getNombre());
        ps.setString(2, medicoModificado.getApellidos());
        ps.setString(3, medicoModificado.getEspecialidad());
        ps.setString(4, medicoModificado.getTelefono());
        ps.setInt(5, medicoModificado.getId());
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Médico con ID " + medicoModificado.getId() + " modificado correctamente.");
        } else {
            System.out.println("No se encontró el médico con ID " + medicoModificado.getId());
        }

        con.closeConexion();
    }

    private ArrayList<Medico> readMySQL() throws SQLException {
        ArrayList<Medico> medicos = new ArrayList<>();
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "SELECT * FROM Medico";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        java.sql.ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Medico medico = new Medico(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("especialidad"),
                    rs.getString("telefono")
            );
            medicos.add(medico);
        }

        con.closeConexion();
        return medicos;
    }
}
