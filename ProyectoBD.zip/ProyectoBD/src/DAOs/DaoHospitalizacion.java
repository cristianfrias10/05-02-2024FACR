package DAOs;
    import Clases.Hospitalizacion;
    import java.sql.SQLException;
    import java.util.ArrayList;
    import java.util.logging.Level;
    import java.util.logging.Logger;

public class DaoHospitalizacion implements IDAOs.IDaoHospitalizacion {

    private java.sql.Connection cxn = null;

    @Override
    public void altasHospitalizacion(Hospitalizacion hospitalizacion) {
        // Guardar datos en un Archivo
        // saveArchivos(hospitalizacion);

        // Guardar datos en MySQL
        try {
            saveMySQL(hospitalizacion);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void bajasHospitalizacion(int id) {
        // Borrar datos en un Archivo
        // deleteArchivos(id);

        // Borrar datos en MySQL
        try {
            deleteMySQL(id);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void modificarHospitalizacion(Hospitalizacion hospitalizacionModificada) {
        // Modificar los datos de un Archivo
        // modifyArchivos(hospitalizacionModificada);

        // Modificar los datos de MySQL
        try {
            modifyMySQL(hospitalizacionModificada);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public ArrayList<Hospitalizacion> obtenerTodasHospitalizaciones() {
        ArrayList<Hospitalizacion> hospitalizaciones = new ArrayList<>();

        // Obtener los datos del Archivo
        // hospitalizaciones = readArchivos();
        // Obtener los datos de MySQL
        try {
            hospitalizaciones = readMySQL();
        } catch (SQLException ex) {
            Logger.getLogger(DaoHospitalizacion.class.getName()).log(Level.SEVERE, "Error al intentar leer los datos de MySQL", ex);
        }

        return hospitalizaciones;
    }

    @Override
    public Hospitalizacion buscarHospitalizacion(int id) {
        ArrayList<Hospitalizacion> hospitalizaciones;
        hospitalizaciones = obtenerTodasHospitalizaciones();

        for (Hospitalizacion hospitalizacion : hospitalizaciones) {
            if (hospitalizacion.getId() == id) {
                return hospitalizacion;
            }
        }
        return null;
    }

    @Override
    public void guardarHospitalizaciones(ArrayList<Hospitalizacion> hospitalizaciones) {
        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream("Hospitalizaciones");
            java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(fos);
            oos.writeObject(hospitalizaciones);
            oos.close();
        } catch (java.io.IOException ex) {
            System.out.println("Error al guardar en el archivo: " + ex.toString());
        }
    }

    private void saveArchivos(Hospitalizacion hospitalizacion) {
        ArrayList<Hospitalizacion> hospitalizaciones;
        hospitalizaciones = obtenerTodasHospitalizaciones();
        hospitalizaciones.add(hospitalizacion);
        guardarHospitalizaciones(hospitalizaciones);
    }

    private void deleteArchivos(int id) {
        ArrayList<Hospitalizacion> hospitalizaciones;
        hospitalizaciones = obtenerTodasHospitalizaciones();

        for (int i = 0; i < hospitalizaciones.size(); i++) {
            if (hospitalizaciones.get(i).getId() == id) {
                hospitalizaciones.remove(i);
                break;
            }
        }

        guardarHospitalizaciones(hospitalizaciones);
    }

    private void modifyArchivos(Hospitalizacion hospitalizacionModificada) {
        ArrayList<Hospitalizacion> hospitalizaciones;
        hospitalizaciones = obtenerTodasHospitalizaciones();

        for (int i = 0; i < hospitalizaciones.size(); i++) {
            if (hospitalizaciones.get(i).getId() == hospitalizacionModificada.getId()) {
                hospitalizaciones.set(i, hospitalizacionModificada);
                break;
            }
        }

        guardarHospitalizaciones(hospitalizaciones);
    }

    private ArrayList<Hospitalizacion> readArchivos() {
        ArrayList<Hospitalizacion> hospitalizaciones = new ArrayList<>();

        try {
            java.io.FileInputStream fis = new java.io.FileInputStream("Hospitalizaciones");
            java.io.ObjectInputStream ois = new java.io.ObjectInputStream(fis);
            hospitalizaciones = (ArrayList<Hospitalizacion>) ois.readObject();
            ois.close();
        } catch (java.io.IOException | ClassNotFoundException ex) {
            // Si ocurre un error al leer el archivo, se muestra el mensaje de error
            System.out.println("Error al leer el archivo de hospitalizaciones: " + ex.getMessage());
        }

        return hospitalizaciones;
    }

    private void saveMySQL(Hospitalizacion hospitalizacion) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "INSERT INTO Hospitalizacion(id, paciente_id, habitacion_id, fecha_ingreso, fecha_alta) VALUES(?, ?, ?, ?, ?)";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, hospitalizacion.getId());
        ps.setInt(2, hospitalizacion.getPaciente_id());
        ps.setInt(3, hospitalizacion.getHabitacion_id());
        ps.setString(4, hospitalizacion.getFecha_ingreso());
        ps.setString(5, hospitalizacion.getFecha_alta());
        ps.executeUpdate();

        con.closeConexion();
    }

    private void deleteMySQL(int id) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "DELETE FROM Hospitalizacion WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, id);
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Hospitalización con ID " + id + " eliminada correctamente.");
        } else {
            System.out.println("No se encontró la hospitalización con ID: " + id);
        }

        con.closeConexion();
    }

    private void modifyMySQL(Hospitalizacion hospitalizacionModificada) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "UPDATE Hospitalizacion SET paciente_id = ?, habitacion_id = ?, fecha_ingreso = ?, fecha_alta = ? WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, hospitalizacionModificada.getPaciente_id());
        ps.setInt(2, hospitalizacionModificada.getHabitacion_id());
        ps.setString(3, hospitalizacionModificada.getFecha_ingreso());
        ps.setString(4, hospitalizacionModificada.getFecha_alta());
        ps.setInt(5, hospitalizacionModificada.getId());
        ps.executeUpdate();

        con.closeConexion();
    }

    private ArrayList<Hospitalizacion> readMySQL() throws SQLException {
        ArrayList<Hospitalizacion> hospitalizaciones = new ArrayList<>();
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "SELECT * FROM Hospitalizacion";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        java.sql.ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Hospitalizacion hospitalizacion = new Hospitalizacion(
                    rs.getInt("id"),
                    rs.getInt("paciente_id"),
                    rs.getInt("habitacion_id"),
                    rs.getString("fecha_ingreso"),
                    rs.getString("fecha_alta")
            );
            hospitalizaciones.add(hospitalizacion);
        }

        con.closeConexion();
        return hospitalizaciones;
    }
}
