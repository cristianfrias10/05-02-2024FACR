package DAOs;
    import Clases.Paciente;
    import java.sql.SQLException;
    import java.util.ArrayList;
    import java.util.logging.Level;
    import java.util.logging.Logger;

public class DaoPaciente implements IDAOs.IDaoPaciente {

    private java.sql.Connection cxn = null;

    @Override
    public void altasPaciente(Paciente paciente) {
        // Guardar datos en un Archivo
        // saveArchivos(paciente);

        // Guardar datos en MySQL
        try {
            saveMySQL(paciente);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void bajasPaciente(int id) {
        // Borrar datos en un Archivo
        // deleteArchivos(id);

        // Borrar datos en MySQL
        try {
            deleteMySQL(id);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public void modificarPaciente(Paciente pacienteModificado) {
        // Modificar los datos de un Archivo
        // modifyArchivos(pacienteModificado);

        // Modificar los datos de MySQL
        try {
            modifyMySQL(pacienteModificado);
        } catch (SQLException ex) {
            System.out.println("Error:" + ex.getMessage());
        }
    }

    @Override
    public ArrayList<Paciente> obtenerTodosPacientes() {
        ArrayList<Paciente> pacientes = new ArrayList<>();

        // Obtener los datos del Archivo
        // pacientes = readArchivos();
        // Obtener los datos de MySQL
        try {
            pacientes = readMySQL();
        } catch (SQLException ex) {
            Logger.getLogger(DaoPaciente.class.getName()).log(Level.SEVERE, "Error al intentar leer los datos de MySQL", ex);
        }

        return pacientes;
    }

    @Override
    public Paciente buscarPaciente(int id) {
        ArrayList<Paciente> pacientes;
        pacientes = obtenerTodosPacientes();

        for (Paciente paciente : pacientes) {
            if (paciente.getId() == id) {
                return paciente;
            }
        }
        return null;
    }

    @Override
    public void guardarPacientes(ArrayList<Paciente> pacientes) {
        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream("Pacientes");
            java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(fos);
            oos.writeObject(pacientes);
            oos.close();
        } catch (java.io.IOException ex) {
            System.out.println("Error al guardar en el archivo: " + ex.toString());
        }
    }

    private void saveArchivos(Paciente paciente) {
        ArrayList<Paciente> pacientes;
        pacientes = obtenerTodosPacientes();
        pacientes.add(paciente);
        guardarPacientes(pacientes);
    }

    private void deleteArchivos(int id) {
        ArrayList<Paciente> pacientes;
        pacientes = obtenerTodosPacientes();

        for (int i = 0; i < pacientes.size(); i++) {
            if (pacientes.get(i).getId() == id) {
                pacientes.remove(i);
                break;
            }
        }

        guardarPacientes(pacientes);
    }

    private void modifyArchivos(Paciente pacienteModificado) {
        ArrayList<Paciente> pacientes;
        pacientes = obtenerTodosPacientes();

        for (int i = 0; i < pacientes.size(); i++) {
            if (pacientes.get(i).getId() == pacienteModificado.getId()) {
                pacientes.set(i, pacienteModificado);
                break;
            }
        }

        guardarPacientes(pacientes);
    }

    private ArrayList<Paciente> readArchivos() {
        ArrayList<Paciente> pacientes = new ArrayList<>();

        try {
            java.io.FileInputStream fis = new java.io.FileInputStream("Pacientes");
            java.io.ObjectInputStream ois = new java.io.ObjectInputStream(fis);
            pacientes = (ArrayList<Paciente>) ois.readObject();
            ois.close();
        } catch (java.io.IOException | ClassNotFoundException ex) {
            // Si ocurre un error al leer el archivo, se muestra el mensaje de error
            System.out.println("Error al leer el archivo de pacientes: " + ex.getMessage());
        }

        return pacientes;
    }

    private void saveMySQL(Paciente paciente) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "INSERT INTO Paciente(id, nombre, apellidos, fecha_nacimiento, direccion, telefono) VALUES(?, ?, ?, ?, ?, ?)";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, paciente.getId());
        ps.setString(2, paciente.getNombre());
        ps.setString(3, paciente.getApellidos());
        ps.setString(4, paciente.getFecha_nacimiento());
        ps.setString(5, paciente.getDireccion());
        ps.setString(6, paciente.getTelefono());
        ps.executeUpdate();

        con.closeConexion();
    }

    private void deleteMySQL(int id) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "DELETE FROM Paciente WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setInt(1, id);
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Paciente con ID " + id + " eliminado correctamente.");
        } else {
            System.out.println("No se encontró el paciente con ID: " + id);
        }

        con.closeConexion();
    }

    private void modifyMySQL(Paciente pacienteModificado) throws SQLException {
        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "UPDATE Paciente SET nombre = ?, apellidos = ?, fecha_nacimiento = ?, direccion = ?, telefono = ? WHERE id = ?";
        java.sql.PreparedStatement ps;

        ps = cxn.prepareStatement(sql);
        ps.setString(1, pacienteModificado.getNombre());
        ps.setString(2, pacienteModificado.getApellidos());
        ps.setString(3, pacienteModificado.getFecha_nacimiento());
        ps.setString(4, pacienteModificado.getDireccion());
        ps.setString(5, pacienteModificado.getTelefono());
        ps.setInt(6, pacienteModificado.getId());
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Paciente con ID " + pacienteModificado.getId() + " modificado correctamente.");
        } else {
            System.out.println("No se encontró el paciente con ID " + pacienteModificado.getId());
        }

        con.closeConexion();
    }

    private ArrayList<Paciente> readMySQL() throws SQLException {
        ArrayList<Paciente> pacientes;
        pacientes = new ArrayList<>();

        ConexionMySQL.Conexion con = new ConexionMySQL.Conexion();
        cxn = con.getConexion();

        String sql = "SELECT * FROM Paciente";
        try (java.sql.PreparedStatement ps = cxn.prepareStatement(sql); java.sql.ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String apellidos = rs.getString("apellidos");
                String fecha_nacimiento = rs.getString("fecha_nacimiento");
                String direccion = rs.getString("direccion");
                String telefono = rs.getString("telefono");
                Paciente paciente = new Paciente(id, nombre, apellidos, fecha_nacimiento, direccion, telefono);
                pacientes.add(paciente);
            }
        } catch (java.sql.SQLException ex) {
            System.out.println("Error al intentar leer los datos de MySQL: " + ex.getMessage());
        }

        con.closeConexion();
        return pacientes;
    }
}
