package CRUDCita;
    import Clases.Cita;
    import DAOs.DaoCita;
    import java.util.ArrayList;
    import javax.swing.JOptionPane;

public class AltasCita extends javax.swing.JFrame {
    private java.util.ArrayList<Cita> citas;
    
    private java.util.ArrayList<Clases.Paciente> pas;
    private java.util.ArrayList<Clases.Medico> med;
    
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblPacienteId;
    private javax.swing.JLabel lblMedicoId;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblHora;
    
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnMostrar;
    
    private javax.swing.JTextField txtId;
    private javax.swing.JComboBox<Integer> asignarPasiente;
    private javax.swing.JComboBox<Integer> asignarMedico;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtHora;

    public AltasCita() {
        citas = new java.util.ArrayList<>();
        super.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = new java.awt.Dimension(640, 320);
        super.setSize(d);
        super.setTitle("ALTAS CITA");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(204, 229, 255));
        
        lblId = new javax.swing.JLabel("ID:");
        lblId.setBounds(50, 20, 180, 30);
        
        lblPacienteId = new javax.swing.JLabel("Paciente ID:");
        lblPacienteId.setBounds(50, 50, 180, 30);
        
        lblMedicoId = new javax.swing.JLabel("Medico ID:");
        lblMedicoId.setBounds(50, 80, 180, 30);
        
        lblFecha = new javax.swing.JLabel("Fecha:");
        lblFecha.setBounds(50, 110, 180, 30);
        
        lblHora = new javax.swing.JLabel("Hora:");
        lblHora.setBounds(50, 140, 180, 30);
        
        txtId = new javax.swing.JTextField();
        txtId.setBounds(140, 20, 100, 30);
        
        asignarPasiente = new javax.swing.JComboBox<>();
        asignarPasiente.setBounds(140, 50, 150, 30);
        asignarPasiente.setModel(new javax.swing.DefaultComboBoxModel<>(new Integer[] {1, 2, 3, 4}));
        
        asignarMedico = new javax.swing.JComboBox<>();
        asignarMedico.setBounds(140, 80, 170, 30);
        asignarMedico .setModel(new javax.swing.DefaultComboBoxModel<>(new Integer[] {1, 2, 3, 4}));
        
        txtFecha = new javax.swing.JTextField();
        txtFecha.setBounds(140, 110, 100, 30);
        
        txtHora = new javax.swing.JTextField();
        txtHora.setBounds(140, 140, 100, 30);
        
        btnGuardar = new javax.swing.JButton("Guardar");
        btnGuardar.setBounds(50, 200, 100, 40);
        btnGuardar.setBackground(new java.awt.Color(175, 238, 238));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnGuardar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGuardar.addActionListener((java.awt.event.ActionEvent e) -> {
            boolean datosIngresados = !txtId.getText().isEmpty() || !txtFecha.getText().isEmpty() || !txtHora.getText().isEmpty();
    
            if(!datosIngresados) {
                javax.swing.JOptionPane.showMessageDialog(this, "No se han ingresado datos para guardar.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            if(txtId.getText().isEmpty() || txtFecha.getText().isEmpty() || txtHora.getText().isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Todos los campos deben ser llenados.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            int id = Integer.parseInt(txtId.getText());
            int pacienteId = (int) asignarPasiente.getSelectedItem();
            int medicoId = (int) asignarMedico.getSelectedItem();
            String fecha = txtFecha.getText();
            String hora = txtHora.getText();
            Clases.Cita cita = new Clases.Cita(id, pacienteId, medicoId, fecha, hora);
            
            DAOs.DaoCita daoCita = new DAOs.DaoCita();
            daoCita.altasCita(cita);
            JOptionPane.showMessageDialog(this, "Cita Registrada");
            
            txtId.setText("");
            txtFecha.setText("");
            txtHora.setText("");
        });
        
        btnMostrar = new javax.swing.JButton("Mostrar");
        btnMostrar.setBounds(160, 200, 100, 40);
        btnMostrar.setBackground(new java.awt.Color(175, 238, 238));
        btnMostrar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnMostrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnMostrar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            //Abrir Reportes del Archivo
            //reportes.setVisible(true);
            
            //Abrir Reportes de MySQL
            CRUDCita.MDCita md = new CRUDCita.MDCita();
            md.setVisible(true);
        });
        
        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(320, 200, 100, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
        
            MenusOpciones.MPCita menuPrincipal = new MenusOpciones.MPCita();
            menuPrincipal.setVisible(true);
        });
        

        super.add(lblId);
        super.add(lblPacienteId);
        super.add(lblMedicoId);
        super.add(lblFecha);
        super.add(lblHora);
        
        super.add(txtId);
        super.add(asignarPasiente);
        super.add(asignarMedico);
        super.add(txtFecha);
        super.add(txtHora);
        
        super.add(btnRegresar);
        super.add(btnGuardar);
        super.add(btnMostrar);
        
        cargarDatosPasiente();
        cargarDatosMedico();
    }
    
    private void cargarDatosPasiente() {
        DAOs.DaoPaciente daoPasiente = new DAOs.DaoPaciente();
        pas = daoPasiente.obtenerTodosPacientes();
        
        llenarComboBoxPasientes();
    }
    
    private void llenarComboBoxPasientes() {
        asignarPasiente.removeAllItems();

        for (Clases.Paciente pasientes : pas) {
            asignarPasiente.addItem(pasientes.getId());
        }
    }
    
    private void cargarDatosMedico() {
        DAOs.DaoMedico daoMedico = new DAOs.DaoMedico();
        med = daoMedico.obtenerTodosMedicos();
        
        llenarComboBoxMedicos();
    }
    
    private void llenarComboBoxMedicos() {
        asignarMedico.removeAllItems();

        for (Clases.Medico medicos : med) {
            asignarMedico.addItem(medicos.getId());
        }
    }
}