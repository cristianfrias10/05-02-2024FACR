package CRUDCita;
    import Clases.Cita;
    import DAOs.DaoCita;
    import java.util.ArrayList;
    import javax.swing.JOptionPane;

public class ModificarCita extends javax.swing.JFrame {
    private ArrayList<Cita> citas;
    
    private java.util.ArrayList<Clases.Paciente> pas;
    private java.util.ArrayList<Clases.Medico> med;
    
    private int indiceActual = 0;
    
    private javax.swing.JLabel lblTDatos;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblPacienteId;
    private javax.swing.JLabel lblMedicoId;
    private javax.swing.JLabel lblFechaCita;
    private javax.swing.JLabel lblHoraCita;

    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnRegresar;
    
    private javax.swing.JTextField txtModificar;
    private javax.swing.JTextField txtId;
    private javax.swing.JComboBox<Integer> asignarPasiente;
    private javax.swing.JComboBox<Integer> asignarMedico;
    private javax.swing.JTextField txtFechaCita;
    private javax.swing.JTextField txtHoraCita;

    public ModificarCita() {
        super.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 320;
        d.width = 640;

        super.setSize(d);
        super.setTitle("MODIFICAR CITAS");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(204, 229, 255));
        
        lblTDatos = new javax.swing.JLabel("INGRESA EL ID DE LA CITA A MODIFICAR:");
        lblTDatos.setBounds(50, 20, 350, 30);

        lblId = new javax.swing.JLabel("ID:");
        lblId.setBounds(50, 70, 180, 30);

        lblPacienteId = new javax.swing.JLabel("Paciente ID:");
        lblPacienteId.setBounds(50, 100, 180, 30);

        lblMedicoId = new javax.swing.JLabel("Medico ID:");
        lblMedicoId.setBounds(50, 130, 180, 30);

        lblFechaCita = new javax.swing.JLabel("Fecha de Cita:");
        lblFechaCita.setBounds(50, 160, 180, 30);

        lblHoraCita = new javax.swing.JLabel("Hora de Cita:");
        lblHoraCita.setBounds(50, 190, 180, 30);

        txtModificar = new javax.swing.JTextField();
        txtModificar.setBounds(370, 20, 100, 30);

        txtId = new javax.swing.JTextField();
        txtId.setBounds(250, 70, 100, 30);

        asignarPasiente = new javax.swing.JComboBox<>();
        asignarPasiente.setBounds(250, 100, 150, 30);
        asignarPasiente.setModel(new javax.swing.DefaultComboBoxModel<>(new Integer[] {1, 2, 3, 4}));

        asignarMedico = new javax.swing.JComboBox<>();
        asignarMedico.setBounds(250, 130, 170, 30);
        asignarMedico .setModel(new javax.swing.DefaultComboBoxModel<>(new Integer[] {1, 2, 3, 4}));

        txtFechaCita = new javax.swing.JTextField();
        txtFechaCita.setBounds(250, 160, 100, 30);

        txtHoraCita = new javax.swing.JTextField();
        txtHoraCita.setBounds(250, 190, 100, 30);

        btnBuscar = new javax.swing.JButton("Buscar");
        btnBuscar.setBounds(480, 20, 100, 30);
        btnBuscar.setBackground(new java.awt.Color(175, 238, 238));
        btnBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((java.awt.event.ActionEvent e) -> {
            String idBuscar = txtModificar.getText().trim();

            if (idBuscar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese un ID a buscar.");
            } else {
                int id = Integer.parseInt(idBuscar);
                DaoCita daoCita = new DaoCita();
                Cita cita = daoCita.buscarCita(id);

                if (cita != null) {
                    mostrarDatos(cita);
                } else {
                    JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                }

                txtModificar.setText("");
            }
        });

        btnModificar = new javax.swing.JButton("Modificar");
        btnModificar.setBounds(490, 100, 100, 40);
        btnModificar.setBackground(new java.awt.Color(175, 238, 238));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnModificar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificar.addActionListener((java.awt.event.ActionEvent e) -> {
            String idModificar = txtId.getText().trim();
            Integer nuevoPacienteId = (Integer) asignarPasiente.getSelectedItem();
            String nuevoPacienteIdStr = nuevoPacienteId.toString();
            Integer nuevoMedicoId = (Integer) asignarMedico.getSelectedItem();
            String nuevoMedicoIdStr = nuevoMedicoId.toString();
            String nuevaFechaCita = txtFechaCita.getText().trim();
            String nuevaHoraCita = txtHoraCita.getText().trim();

            if (idModificar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese el ID de la cita a modificar.");
                return;
            }

            int id = Integer.parseInt(idModificar);
            DaoCita daoCita = new DaoCita();
            Cita citaModificar = daoCita.buscarCita(id);

            if (citaModificar == null) {
                JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                return;
            }

            if (!nuevoPacienteIdStr.isEmpty()) {
                citaModificar.setPaciente_id(Integer.parseInt(nuevoPacienteIdStr));
            }
            if (!nuevoMedicoIdStr.isEmpty()) {
                citaModificar.setMedico_id(Integer.parseInt(nuevoMedicoIdStr));
            }
            if (!nuevaFechaCita.isEmpty()) {
                citaModificar.setFecha_cita(nuevaFechaCita);
            }
            if (!nuevaHoraCita.isEmpty()) {
                citaModificar.setHora_cita(nuevaHoraCita);
            }

            daoCita.modificarCita(citaModificar);

            JOptionPane.showMessageDialog(this, "Los datos se han modificado correctamente.");

            txtId.setText("");
            txtFechaCita.setText("");
            txtHoraCita.setText("");
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(490, 150, 100, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
        
            MenusOpciones.MPCita menuPrincipal = new MenusOpciones.MPCita();
            menuPrincipal.setVisible(true);
        });

        super.add(lblTDatos);
        super.add(lblId);
        super.add(lblPacienteId);
        super.add(lblMedicoId);
        super.add(lblFechaCita);
        super.add(lblHoraCita);

        super.add(btnBuscar);
        super.add(btnModificar);
        super.add(btnRegresar);

        super.add(txtModificar);
        super.add(txtId);
        super.add(asignarMedico);
        super.add(asignarPasiente);
        super.add(txtFechaCita);
        super.add(txtHoraCita);

        mostrarDatos(indiceActual);
        
        cargarDatosPasiente();
        cargarDatosMedico();
    }

    private void mostrarDatos(int index) {
        DaoCita daoCita = new DaoCita();
        citas = daoCita.obtenerTodasCitas();

        if (index >= 0 && index < citas.size()) {
            Cita cita = citas.get(index);
            lblId.setText("ID: " + cita.getId());
            lblPacienteId.setText("Paciente ID: " + cita.getPaciente_id());
            lblMedicoId.setText("Medico ID: " + cita.getMedico_id());
            lblFechaCita.setText("Fecha de Cita: " + cita.getFecha_cita());
            lblHoraCita.setText("Hora de Cita: " + cita.getHora_cita());
        }
    }

    private void mostrarDatos(Cita cita) {
        if (cita != null) {
            lblId.setText("ID: " + cita.getId());
            lblPacienteId.setText("Paciente ID: " + cita.getPaciente_id());
            lblMedicoId.setText("Medico ID: " + cita.getMedico_id());
            lblFechaCita.setText("Fecha de Cita: " + cita.getFecha_cita());
            lblHoraCita.setText("Hora de Cita: " + cita.getHora_cita());
        }
    }
    
    private void cargarDatosPasiente() {
        DAOs.DaoPaciente daoPasiente = new DAOs.DaoPaciente();
        pas = daoPasiente.obtenerTodosPacientes();
        
        llenarComboBoxPasientes();
    }
    
    private void llenarComboBoxPasientes() {
        asignarPasiente.removeAllItems();

        for (Clases.Paciente pasientes : pas) {
            asignarPasiente.addItem(pasientes.getId());
        }
    }
    
    private void cargarDatosMedico() {
        DAOs.DaoMedico daoMedico = new DAOs.DaoMedico();
        med = daoMedico.obtenerTodosMedicos();
        
        llenarComboBoxMedicos();
    }
    
    private void llenarComboBoxMedicos() {
        asignarMedico.removeAllItems();

        for (Clases.Medico medicos : med) {
            asignarMedico.addItem(medicos.getId());
        }
    }
}
