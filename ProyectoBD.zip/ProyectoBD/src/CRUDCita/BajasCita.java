package CRUDCita;
    import Clases.Cita;
    import DAOs.DaoCita;
    import java.util.ArrayList;

public class BajasCita extends javax.swing.JFrame {
    private java.util.ArrayList<Clases.Cita> cita;
    
    private int indiceActual = 0;
    
    private javax.swing.JLabel lblElegir;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblPacienteID;
    private javax.swing.JLabel lblMedicoID;
    private javax.swing.JLabel lblFechaCita;
    private javax.swing.JLabel lblHoraCita;

    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnRegresar;

    private javax.swing.JTextField txtID;

    public BajasCita() {
        initComponents();
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 320;
        d.width = 640;
        
        super.setSize(d);
        setTitle("BAJAS CITAS");
        setLayout(null);
        getContentPane().setBackground(new java.awt.Color(204, 229, 255));

        lblElegir = new javax.swing.JLabel("ID de la Cita:");
        lblElegir.setBounds(50, 20, 180, 30);

        lblID = new javax.swing.JLabel("ID:");
        lblID.setBounds(50, 80, 180, 30);

        lblPacienteID = new javax.swing.JLabel("Paciente ID:");
        lblPacienteID.setBounds(50, 110, 180, 30);

        lblMedicoID = new javax.swing.JLabel("Médico ID:");
        lblMedicoID.setBounds(50, 140, 180, 30);

        lblFechaCita = new javax.swing.JLabel("Fecha Cita:");
        lblFechaCita.setBounds(50, 170, 180, 30);

        lblHoraCita = new javax.swing.JLabel("Hora Cita:");
        lblHoraCita.setBounds(50, 200, 180, 30);

        btnBorrar = new javax.swing.JButton("Dar de Baja");
        btnBorrar.setBounds(250, 230, 130, 40);
        btnBorrar.setBackground(new java.awt.Color(175, 238, 238));
        btnBorrar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnBorrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBorrar.addActionListener((java.awt.event.ActionEvent e) -> {
            DaoCita daoCita = new DaoCita();
            String idText = txtID.getText();

            try {
                int id = Integer.parseInt(idText);
                Cita citaBorrar = daoCita.buscarCita(id);

                if (citaBorrar != null) {
                    daoCita.bajasCita(id);
                    javax.swing.JOptionPane.showMessageDialog(this, "Cita borrada exitosamente.");

                    mostrarDatos(citaBorrar);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "Cita no encontrada.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID de la cita.");
            }
            txtID.setText("");
        });

        btnBuscar = new javax.swing.JButton("Buscar");
        btnBuscar.setBounds(250, 20, 100, 30);
        btnBuscar.setBackground(new java.awt.Color(175, 238, 238));
        btnBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((java.awt.event.ActionEvent e) -> {
            DaoCita daoCita = new DaoCita();
            String idText = txtID.getText();

            try {
                int id = Integer.parseInt(idText);
                Cita cita = daoCita.buscarCita(id);

                if (cita != null) {
                    mostrarDatos(cita);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "Cita no encontrada.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID de la cita.");
            }
            txtID.setText("");
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(410, 230, 130, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
        
            MenusOpciones.MPCita menuPrincipal = new MenusOpciones.MPCita();
            menuPrincipal.setVisible(true);
        });

        txtID = new javax.swing.JTextField();
        txtID.setBounds(180, 20, 60, 30);
        
        mostrarDatos(indiceActual);

        super.add(lblElegir);
        super.add(lblID);
        super.add(lblPacienteID);
        super.add(lblMedicoID);
        super.add(lblFechaCita);
        super.add(lblHoraCita);
        super.add(btnBorrar);
        super.add(btnBuscar);
        super.add(btnRegresar);
        super.add(txtID);
        
        mostrarDatos(indiceActual);
    }

    private void mostrarDatos(Cita cita) {
        if (cita != null) {
            lblID.setText("ID: " + cita.getId());
            lblPacienteID.setText("Paciente ID: " + cita.getPaciente_id());
            lblMedicoID.setText("Médico ID: " + cita.getMedico_id());
            lblFechaCita.setText("Fecha Cita: " + cita.getFecha_cita());
            lblHoraCita.setText("Hora Cita: " + cita.getHora_cita());
        }
    }

    private void mostrarDatos(int index) {
        DAOs.DaoCita daoAlumno = new DAOs.DaoCita();
        cita = daoAlumno.obtenerTodasCitas();
        
        if (index >= 0 && index < cita.size()) {
            Clases.Cita cit = cita.get(index);
            lblID.setText("ID: " + cit.getId());
            lblPacienteID.setText("Paciente ID: " + cit.getPaciente_id());
            lblMedicoID.setText("Médico ID: " + cit.getMedico_id());
            lblFechaCita.setText("Fecha Cita: " + cit.getFecha_cita());
            lblHoraCita.setText("Hora Cita: " + cit.getHora_cita());
        }
    }
}
