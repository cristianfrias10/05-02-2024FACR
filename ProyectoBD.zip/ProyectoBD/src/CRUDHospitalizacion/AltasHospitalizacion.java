package CRUDHospitalizacion;
    import Clases.Hospitalizacion;
    import DAOs.DaoHospitalizacion;
    import java.util.ArrayList;
    import javax.swing.JOptionPane;

public class AltasHospitalizacion extends javax.swing.JFrame {

    private java.util.ArrayList<Hospitalizacion> hospitalizaciones;

    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblPacienteId;
    private javax.swing.JLabel lblHabitacionId;
    private javax.swing.JLabel lblFechaIngreso;
    private javax.swing.JLabel lblFechaAlta;

    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnMostrar;

    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtPacienteId;
    private javax.swing.JTextField txtHabitacionId;
    private javax.swing.JTextField txtFechaIngreso;
    private javax.swing.JTextField txtFechaAlta;

    public AltasHospitalizacion() {
        hospitalizaciones = new java.util.ArrayList<>();
        super.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 320;
        d.width = 640;

        super.setSize(d);
        super.setTitle("ALTAS HOSPITALIZACIONES");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(255,239,213));

        lblId = new javax.swing.JLabel("ID:");
        lblId.setBounds(50, 20, 180, 30);

        lblPacienteId = new javax.swing.JLabel("Paciente ID:");
        lblPacienteId.setBounds(50, 50, 180, 30);

        lblHabitacionId = new javax.swing.JLabel("Habitación ID:");
        lblHabitacionId.setBounds(50, 80, 180, 30);

        lblFechaIngreso = new javax.swing.JLabel("Fecha Ingreso:");
        lblFechaIngreso.setBounds(50, 110, 180, 30);

        lblFechaAlta = new javax.swing.JLabel("Fecha Alta:");
        lblFechaAlta.setBounds(50, 140, 180, 30);

        txtId = new javax.swing.JTextField();
        txtId.setBounds(140, 20, 100, 30);

        txtPacienteId = new javax.swing.JTextField();
        txtPacienteId.setBounds(140, 50, 150, 30);

        txtHabitacionId = new javax.swing.JTextField();
        txtHabitacionId.setBounds(140, 80, 170, 30);

        txtFechaIngreso = new javax.swing.JTextField();
        txtFechaIngreso.setBounds(140, 110, 100, 30);

        txtFechaAlta = new javax.swing.JTextField();
        txtFechaAlta.setBounds(140, 140, 100, 30);

        btnGuardar = new javax.swing.JButton("Guardar");
        btnGuardar.setBounds(50, 200, 100, 40);
        btnGuardar.setBackground(new java.awt.Color(175, 238, 238));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnGuardar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGuardar.addActionListener((java.awt.event.ActionEvent e) -> {
            boolean datosIngresados = !txtId.getText().isEmpty() || !txtPacienteId.getText().isEmpty() || !txtHabitacionId.getText().isEmpty() || !txtFechaIngreso.getText().isEmpty() || !txtFechaAlta.getText().isEmpty();

            if (!datosIngresados) {
                javax.swing.JOptionPane.showMessageDialog(this, "No se han ingresado datos para guardar.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (txtId.getText().isEmpty() || txtPacienteId.getText().isEmpty() || txtHabitacionId.getText().isEmpty() || txtFechaIngreso.getText().isEmpty() || txtFechaAlta.getText().isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Todos los campos deben ser llenados.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            int id = Integer.parseInt(txtId.getText());
            int pacienteId = Integer.parseInt(txtPacienteId.getText());
            int habitacionId = Integer.parseInt(txtHabitacionId.getText());
            String fechaIngreso = txtFechaIngreso.getText();
            String fechaAlta = txtFechaAlta.getText();
            Hospitalizacion hospitalizacion = new Hospitalizacion(id, pacienteId, habitacionId, fechaIngreso, fechaAlta);

            DaoHospitalizacion daoHospitalizacion = new DaoHospitalizacion();
            daoHospitalizacion.altasHospitalizacion(hospitalizacion);
            JOptionPane.showMessageDialog(this, "Hospitalizado Correctamente");

            txtId.setText("");
            txtPacienteId.setText("");
            txtHabitacionId.setText("");
            txtFechaIngreso.setText("");
            txtFechaAlta.setText("");

        });

        btnMostrar = new javax.swing.JButton("Mostrar");
        btnMostrar.setBounds(160, 200, 100, 40);
        btnMostrar.setBackground(new java.awt.Color(175, 238, 238));
        btnMostrar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnMostrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnMostrar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();

            CRUDHospitalizacion.MDHospitalizacion vMySQL = new CRUDHospitalizacion.MDHospitalizacion();
            vMySQL.setVisible(true);
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(270, 200, 100, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();

            MenusOpciones.MPHospitalizacion menuPrincipal = new MenusOpciones.MPHospitalizacion();
            menuPrincipal.setVisible(true);
        });

        super.add(lblId);
        super.add(lblPacienteId);
        super.add(lblHabitacionId);
        super.add(lblFechaIngreso);
        super.add(lblFechaAlta);

        super.add(txtId);
        super.add(txtPacienteId);
        super.add(txtHabitacionId);
        super.add(txtFechaIngreso);
        super.add(txtFechaAlta);

        super.add(btnRegresar);
        super.add(btnGuardar);
        super.add(btnMostrar);
    }

}
