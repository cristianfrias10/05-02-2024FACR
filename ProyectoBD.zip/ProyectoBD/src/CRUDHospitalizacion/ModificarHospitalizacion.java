package CRUDHospitalizacion;
    import DAOs.DaoHospitalizacion;
    import Clases.Hospitalizacion;
    import java.awt.Color;
    import java.awt.Dimension;
    import java.awt.Toolkit;
    import java.awt.event.ActionEvent;
    import javax.swing.*;

public class ModificarHospitalizacion extends JFrame {
    private java.util.ArrayList<Hospitalizacion> hospitalizaciones;
    private int indiceActual = 0;

    private JLabel lblTDatos;
    private JLabel lblId;
    private JLabel lblPacienteId;
    private JLabel lblHabitacionId;
    private JLabel lblFechaIngreso;
    private JLabel lblFechaAlta;

    private JButton btnBuscar;
    private JButton btnModificar;
    private JButton btnRegresar;

    private JTextField txtModificar;
    private JTextField txtId;
    private JTextField txtPacienteId;
    private JTextField txtHabitacionId;
    private JTextField txtFechaIngreso;
    private JTextField txtFechaAlta;

    public ModificarHospitalizacion() {
        super.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 400;
        d.width = 640;

        super.setSize(d);
        super.setTitle("MODIFICAR HOSPITALIZACION");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(255,239,213));

        lblTDatos = new JLabel("INGRESA EL ID DE LA HOSPITALIZACION A MODIFICAR:");
        lblTDatos.setBounds(50, 20, 350, 30);

        lblId = new JLabel("ID:");
        lblId.setBounds(50, 70, 180, 30);

        lblPacienteId = new JLabel("Paciente ID:");
        lblPacienteId.setBounds(50, 100, 180, 30);

        lblHabitacionId = new JLabel("Habitación ID:");
        lblHabitacionId.setBounds(50, 130, 180, 30);

        lblFechaIngreso = new JLabel("Fecha Ingreso:");
        lblFechaIngreso.setBounds(50, 160, 180, 30);

        lblFechaAlta = new JLabel("Fecha Alta:");
        lblFechaAlta.setBounds(50, 190, 180, 30);

        txtModificar = new JTextField();
        txtModificar.setBounds(370, 20, 100, 30);

        txtId = new JTextField();
        txtId.setBounds(250, 70, 100, 30);

        txtPacienteId = new JTextField();
        txtPacienteId.setBounds(250, 100, 150, 30);

        txtHabitacionId = new JTextField();
        txtHabitacionId.setBounds(250, 130, 170, 30);

        txtFechaIngreso = new JTextField();
        txtFechaIngreso.setBounds(250, 160, 150, 30);

        txtFechaAlta = new JTextField();
        txtFechaAlta.setBounds(250, 190, 170, 30);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(480, 20, 100, 30);
        btnBuscar.setBackground(new Color(175, 238, 238));
        btnBuscar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((ActionEvent e) -> {
            String idBuscar = txtModificar.getText().trim();

            if (idBuscar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese un ID a buscar.");
            } else {
                int id = Integer.parseInt(idBuscar);
                DaoHospitalizacion daoHospitalizacion = new DaoHospitalizacion();
                Hospitalizacion hospitalizacion = daoHospitalizacion.buscarHospitalizacion(id);

                if (hospitalizacion != null) {
                    mostrarDatos(hospitalizacion);
                } else {
                    JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                }

                txtModificar.setText("");
            }
        });

        btnModificar = new JButton("Modificar");
        btnModificar.setBounds(490, 100, 100, 40);
        btnModificar.setBackground(new Color(175, 238, 238));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnModificar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificar.addActionListener((ActionEvent e) -> {
            String idModificar = txtId.getText().trim();
            String nuevoPacienteId = txtPacienteId.getText().trim();
            String nuevoHabitacionId = txtHabitacionId.getText().trim();
            String nuevaFechaIngreso = txtFechaIngreso.getText().trim();
            String nuevaFechaAlta = txtFechaAlta.getText().trim();

            if (idModificar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese el ID de la hospitalización a modificar.");
                return;
            }

            int id = Integer.parseInt(idModificar);
            DaoHospitalizacion daoHospitalizacion = new DaoHospitalizacion();
            Hospitalizacion hospitalizacionModificar = daoHospitalizacion.buscarHospitalizacion(id);

            if (hospitalizacionModificar == null) {
                JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                return;
            }

            if (!nuevoPacienteId.isEmpty()) {
                hospitalizacionModificar.setPaciente_id(Integer.parseInt(nuevoPacienteId));
            }
            if (!nuevoHabitacionId.isEmpty()) {
                hospitalizacionModificar.setHabitacion_id(Integer.parseInt(nuevoHabitacionId));
            }
            if (!nuevaFechaIngreso.isEmpty()) {
                hospitalizacionModificar.setFecha_ingreso(nuevaFechaIngreso);
            }
            if (!nuevaFechaAlta.isEmpty()) {
                hospitalizacionModificar.setFecha_alta(nuevaFechaAlta);
            }

            daoHospitalizacion.modificarHospitalizacion(hospitalizacionModificar);

            JOptionPane.showMessageDialog(this, "Los datos se han modificado correctamente.");

            txtId.setText("");
            txtPacienteId.setText("");
            txtHabitacionId.setText("");
            txtFechaIngreso.setText("");
            txtFechaAlta.setText("");
        });

        btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(490, 150, 100, 40);
        btnRegresar.setBackground(new Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((ActionEvent e) -> {
            this.dispose();

            MenusOpciones.MPHospitalizacion menuPrincipal = new MenusOpciones.MPHospitalizacion();
            menuPrincipal.setVisible(true);
        });

        super.add(lblTDatos);
        super.add(lblId);
        super.add(lblPacienteId);
        super.add(lblHabitacionId);
        super.add(lblFechaIngreso);
        super.add(lblFechaAlta);

        super.add(btnBuscar);
        super.add(btnModificar);
        super.add(btnRegresar);

        super.add(txtModificar);
        super.add(txtId);
        super.add(txtPacienteId);
        super.add(txtHabitacionId);
        super.add(txtFechaIngreso);
        super.add(txtFechaAlta);

        mostrarDatos(indiceActual);
    }

    private void mostrarDatos(int index) {
        DaoHospitalizacion daoHospitalizacion = new DaoHospitalizacion();
        hospitalizaciones = daoHospitalizacion.obtenerTodasHospitalizaciones();

        if (index >= 0 && index < hospitalizaciones.size()) {
            Hospitalizacion hospitalizacion = hospitalizaciones.get(index);
            lblId.setText("ID: " + hospitalizacion.getId());
            lblPacienteId.setText("Paciente ID: " + hospitalizacion.getPaciente_id());
            lblHabitacionId.setText("Habitación ID: " + hospitalizacion.getHabitacion_id());
            lblFechaIngreso.setText("Fecha Ingreso: " + hospitalizacion.getFecha_ingreso());
            lblFechaAlta.setText("Fecha Alta: " + hospitalizacion.getFecha_alta());
        }
    }

    private void mostrarDatos(Hospitalizacion hospitalizacion) {
        if (hospitalizacion != null) {
            lblId.setText("ID: " + hospitalizacion.getId());
            lblPacienteId.setText("Paciente ID: " + hospitalizacion.getPaciente_id());
            lblHabitacionId.setText("Habitación ID: " + hospitalizacion.getHabitacion_id());
            lblFechaIngreso.setText("Fecha Ingreso: " + hospitalizacion.getFecha_ingreso());
            lblFechaAlta.setText("Fecha Alta: " + hospitalizacion.getFecha_alta());

            txtId.setText(String.valueOf(hospitalizacion.getId()));
            txtPacienteId.setText(String.valueOf(hospitalizacion.getPaciente_id()));
            txtHabitacionId.setText(String.valueOf(hospitalizacion.getHabitacion_id()));
            txtFechaIngreso.setText(hospitalizacion.getFecha_ingreso());
            txtFechaAlta.setText(hospitalizacion.getFecha_alta());
        }
    }
}
