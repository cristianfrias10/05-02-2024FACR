package CRUDHospitalizacion;
    import Clases.Hospitalizacion;
    import DAOs.DaoHospitalizacion;
    import java.util.ArrayList;

public class BajasHospitalizacion extends javax.swing.JFrame {
    private java.util.ArrayList<Hospitalizacion> hospitalizaciones;
    private int indiceActual = 0;
    
    private javax.swing.JLabel lblElegir;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblPacienteID;
    private javax.swing.JLabel lblHabitacionID;
    private javax.swing.JLabel lblFechaIngreso;
    private javax.swing.JLabel lblFechaAlta;

    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnRegresar;

    private javax.swing.JTextField txtID;

    public BajasHospitalizacion() {
        initComponents();
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 320;
        d.width = 640;
        
        super.setSize(d);
        setTitle("BAJAS HOSPITALIZACIONES");
        setLayout(null);
        getContentPane().setBackground(new java.awt.Color(255,239,213));

        lblElegir = new javax.swing.JLabel("ID de la Hospitalización:");
        lblElegir.setBounds(50, 20, 180, 30);

        lblID = new javax.swing.JLabel("ID:");
        lblID.setBounds(50, 80, 180, 30);

        lblPacienteID = new javax.swing.JLabel("Paciente ID:");
        lblPacienteID.setBounds(50, 110, 180, 30);

        lblHabitacionID = new javax.swing.JLabel("Habitación ID:");
        lblHabitacionID.setBounds(50, 140, 180, 30);

        lblFechaIngreso = new javax.swing.JLabel("Fecha de Ingreso:");
        lblFechaIngreso.setBounds(50, 170, 180, 30);

        lblFechaAlta = new javax.swing.JLabel("Fecha de Alta:");
        lblFechaAlta.setBounds(50, 200, 180, 30);

        btnBorrar = new javax.swing.JButton("Dar de Baja");
        btnBorrar.setBounds(250, 230, 130, 40);
        btnBorrar.setBackground(new java.awt.Color(175, 238, 238));
        btnBorrar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnBorrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBorrar.addActionListener((java.awt.event.ActionEvent e) -> {
            DaoHospitalizacion daoHospitalizacion = new DaoHospitalizacion();
            String idText = txtID.getText();

            try {
                int id = Integer.parseInt(idText);
                Hospitalizacion hospitalizacionBorrar = daoHospitalizacion.buscarHospitalizacion(id);

                if (hospitalizacionBorrar != null) {
                    daoHospitalizacion.bajasHospitalizacion(id);
                    javax.swing.JOptionPane.showMessageDialog(this, "Hospitalización borrada exitosamente.");

                    mostrarDatos(hospitalizacionBorrar); // Actualizar la vista con los datos borrados
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "Hospitalización no encontrada.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID de la hospitalización.");
            }
            txtID.setText("");
        });

        btnBuscar = new javax.swing.JButton("Buscar");
        btnBuscar.setBounds(300, 20, 100, 30);
        btnBuscar.setBackground(new java.awt.Color(175, 238, 238));
        btnBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((java.awt.event.ActionEvent e) -> {
            DaoHospitalizacion daoHospitalizacion = new DaoHospitalizacion();
            String idText = txtID.getText();

            try {
                int id = Integer.parseInt(idText);
                Hospitalizacion hospitalizacion = daoHospitalizacion.buscarHospitalizacion(id);

                if (hospitalizacion != null) {
                    mostrarDatos(hospitalizacion);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "Hospitalización no encontrada.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID de la hospitalización.");
            }
            txtID.setText("");
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(410, 230, 130, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();

            MenusOpciones.MPHospitalizacion menuPrincipal = new MenusOpciones.MPHospitalizacion();
            menuPrincipal.setVisible(true);
        });

        txtID = new javax.swing.JTextField();
        txtID.setBounds(220, 20, 60, 30);

        add(lblElegir);
        add(lblID);
        add(lblPacienteID);
        add(lblHabitacionID);
        add(lblFechaIngreso);
        add(lblFechaAlta);
        add(btnBorrar);
        add(btnBuscar);
        add(btnRegresar);
        add(txtID);
        
        mostrarDatos(indiceActual);
    }

    private void mostrarDatos(int index) {
        DaoHospitalizacion daoHospitalizacion = new DaoHospitalizacion();
        hospitalizaciones = daoHospitalizacion.obtenerTodasHospitalizaciones();

        if (index >= 0 && index < hospitalizaciones.size()) {
            Hospitalizacion hospitalizacion = hospitalizaciones.get(index);
            lblID.setText("ID: " + hospitalizacion.getId());
            lblPacienteID.setText("Paciente ID: " + hospitalizacion.getPaciente_id());
            lblHabitacionID.setText("Habitación ID: " + hospitalizacion.getHabitacion_id());
            lblFechaIngreso.setText("Fecha Ingreso: " + hospitalizacion.getFecha_ingreso());
            lblFechaAlta.setText("Fecha Alta: " + hospitalizacion.getFecha_alta());
        }
    }

    private void mostrarDatos(Hospitalizacion hospitalizacion) {
        if (hospitalizacion != null) {
            lblID.setText("ID: " + hospitalizacion.getId());
            lblPacienteID.setText("Paciente ID: " + hospitalizacion.getPaciente_id());
            lblHabitacionID.setText("Habitación ID: " + hospitalizacion.getHabitacion_id());
            lblFechaIngreso.setText("Fecha Ingreso: " + hospitalizacion.getFecha_ingreso());
            lblFechaAlta.setText("Fecha Alta: " + hospitalizacion.getFecha_alta());
        }
    }
}    