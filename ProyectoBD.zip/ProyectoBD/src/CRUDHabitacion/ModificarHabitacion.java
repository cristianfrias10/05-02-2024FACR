package CRUDHabitacion;
    import DAOs.DaoHabitacion;
    import Clases.Habitacion;
    import java.awt.Color;
    import java.awt.Dimension;
    import java.awt.Toolkit;
    import java.awt.event.ActionEvent;
    import javax.swing.*;

public class ModificarHabitacion extends JFrame {
    private java.util.ArrayList<Habitacion> habitaciones;
    
    private int indiceActual = 0;
    
    private JLabel lblTDatos;
    private JLabel lblId;
    private JLabel lblNumero;
    private JLabel lblTipo;
    private JLabel lblEstado;

    private JButton btnBuscar;
    private JButton btnModificar;
    private JButton btnRegresar;
    
    private JTextField txtModificar;
    private JTextField txtId;
    private JTextField txtNumero;
    private JTextField txtTipo;
    private JTextField txtEstado;

    public ModificarHabitacion() {
        super.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 320;
        d.width = 640;

        super.setSize(d);
        super.setTitle("MODIFICAR HABITACIONES");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(229,255,204));
        
        lblTDatos = new JLabel("INGRESA EL ID DE LA HABITACIÓN A MODIFICAR:");
        lblTDatos.setBounds(50, 20, 350, 30);

        lblId = new JLabel("ID:");
        lblId.setBounds(50, 70, 180, 30);

        lblNumero = new JLabel("Número:");
        lblNumero.setBounds(50, 100, 180, 30);

        lblTipo = new JLabel("Tipo:");
        lblTipo.setBounds(50, 130, 180, 30);

        lblEstado = new JLabel("Estado:");
        lblEstado.setBounds(50, 160, 180, 30);
        
        txtModificar = new JTextField();
        txtModificar.setBounds(370, 20, 100, 30);
        
        txtId = new JTextField();
        txtId.setBounds(250, 70, 100, 30);
        
        txtNumero = new JTextField();
        txtNumero.setBounds(250, 100, 150, 30);
        
        txtTipo = new JTextField();
        txtTipo.setBounds(250, 130, 170, 30);
        
        txtEstado = new JTextField();
        txtEstado.setBounds(250, 160, 100, 30);
        
        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(480, 20, 100, 30);
        btnBuscar.setBackground(new Color(175,238,238));
        btnBuscar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((ActionEvent e) -> {
            String idBuscar = txtModificar.getText().trim();
    
            if (idBuscar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese un ID a buscar.");
            } else {
                int id = Integer.parseInt(idBuscar);
                DaoHabitacion daoHabitacion = new DaoHabitacion();
                Habitacion habitacion = daoHabitacion.buscarHabitacion(id);

                if (habitacion != null) {
                    mostrarDatos(habitacion);
                } else {
                    JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                }

                txtModificar.setText("");
            }
        });
        
        btnModificar = new JButton("Modificar");
        btnModificar.setBounds(490, 100, 100, 40);
        btnModificar.setBackground(new Color(175,238,238));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnModificar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificar.addActionListener((ActionEvent e) -> {
            String idModificar = txtId.getText().trim();
            String nuevoNumero = txtNumero.getText().trim();
            String nuevoTipo = txtTipo.getText().trim();
            String nuevoEstado = txtEstado.getText().trim();

            if (idModificar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese el ID de la habitación a modificar.");
                return;
            }

            int id = Integer.parseInt(idModificar);
            DaoHabitacion daoHabitacion = new DaoHabitacion();
            Habitacion habitacionModificar = daoHabitacion.buscarHabitacion(id);

            if (habitacionModificar == null) {
                JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                return;
            }

            if (!nuevoNumero.isEmpty()) {
                habitacionModificar.setNumero(nuevoNumero);
            }
            if (!nuevoTipo.isEmpty()) {
                habitacionModificar.setTipo(nuevoTipo);
            }
            if (!nuevoEstado.isEmpty()) {
                habitacionModificar.setEstado(nuevoEstado);
            }

            daoHabitacion.modificarHabitacion(habitacionModificar);

            JOptionPane.showMessageDialog(this, "Los datos se han modificado correctamente.");

            txtId.setText("");
            txtNumero.setText("");
            txtTipo.setText("");
            txtEstado.setText("");
        });
        
        btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(490, 150, 100, 40);
        btnRegresar.setBackground(new Color(192,192,192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((ActionEvent e) -> {
            this.dispose();
        
            MenusOpciones.MPHabitacion menuPrincipal = new MenusOpciones.MPHabitacion();
            menuPrincipal.setVisible(true);
        });
        
        super.add(lblTDatos);
        super.add(lblId);
        super.add(lblNumero);
        super.add(lblTipo);
        super.add(lblEstado);
        
        super.add(btnBuscar);
        super.add(btnModificar);
        super.add(btnRegresar);
        
        super.add(txtModificar);
        super.add(txtId);
        super.add(txtNumero);
        super.add(txtTipo);
        super.add(txtEstado);
        
        mostrarDatos(indiceActual);
    }

    private void mostrarDatos(int index) {
        DaoHabitacion daoHabitacion = new DaoHabitacion();
        habitaciones = daoHabitacion.obtenerTodasHabitaciones();
        
        if (index >= 0 && index < habitaciones.size()) {
            Habitacion habitacion = habitaciones.get(index);
            lblId.setText("ID: " + habitacion.getId());
            lblNumero.setText("Número: " + habitacion.getNumero());
            lblTipo.setText("Tipo: " + habitacion.getTipo());
            lblEstado.setText("Estado: " + habitacion.getEstado());
        }
    }
    
    private void mostrarDatos(Habitacion habitacion) {
        if (habitacion != null) {
            lblId.setText("ID: " + habitacion.getId());
            lblNumero.setText("Número: " + habitacion.getNumero());
            lblTipo.setText("Tipo: " + habitacion.getTipo());
            lblEstado.setText("Estado: " + habitacion.getEstado());
        }
    }
}
