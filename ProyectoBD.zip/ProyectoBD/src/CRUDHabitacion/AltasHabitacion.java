package CRUDHabitacion;
    import Clases.Habitacion;
    import DAOs.DaoHabitacion;
    import java.util.ArrayList;
    import javax.swing.JOptionPane;

public class AltasHabitacion extends javax.swing.JFrame {
    private java.util.ArrayList<Habitacion> habitaciones;
    
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblNumero;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JLabel lblEstado;
    
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnMostrar;
    
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNumero;
    private javax.swing.JTextField txtTipo;
    private javax.swing.JTextField txtEstado;

    public AltasHabitacion() {
        habitaciones = new java.util.ArrayList<>();
        super.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = new java.awt.Dimension(640, 320);
        super.setSize(d);
        super.setTitle("ALTAS HABITACIÓN");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(229,255,204));
        
        lblId = new javax.swing.JLabel("ID:");
        lblId.setBounds(50, 20, 180, 30);
        
        lblNumero = new javax.swing.JLabel("Número:");
        lblNumero.setBounds(50, 50, 180, 30);
        
        lblTipo = new javax.swing.JLabel("Tipo:");
        lblTipo.setBounds(50, 80, 180, 30);
        
        lblEstado = new javax.swing.JLabel("Estado:");
        lblEstado.setBounds(50, 110, 180, 30);
        
        txtId = new javax.swing.JTextField();
        txtId.setBounds(140, 20, 100, 30);
        
        txtNumero = new javax.swing.JTextField();
        txtNumero.setBounds(140, 50, 150, 30);
        
        txtTipo = new javax.swing.JTextField();
        txtTipo.setBounds(140, 80, 170, 30);
        
        txtEstado = new javax.swing.JTextField();
        txtEstado.setBounds(140, 110, 100, 30);
        
        btnGuardar = new javax.swing.JButton("Guardar");
        btnGuardar.setBounds(50, 200, 100, 40);
        btnGuardar.setBackground(new java.awt.Color(175, 238, 238));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnGuardar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGuardar.addActionListener((java.awt.event.ActionEvent e) -> {
            boolean datosIngresados = !txtId.getText().isEmpty() || !txtNumero.getText().isEmpty() || !txtTipo.getText().isEmpty() || !txtEstado.getText().isEmpty();
    
            if(!datosIngresados) {
                javax.swing.JOptionPane.showMessageDialog(this, "No se han ingresado datos para guardar.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            if(txtId.getText().isEmpty() || txtNumero.getText().isEmpty() || txtTipo.getText().isEmpty() || txtEstado.getText().isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Todos los campos deben ser llenados.", "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            int id = Integer.parseInt(txtId.getText());
            String numero = txtNumero.getText();
            String tipo = txtTipo.getText();
            String estado = txtEstado.getText();
            Habitacion habitacion = new Habitacion(id, numero, tipo, estado);
            
            DAOs.DaoHabitacion daoHabitacion = new DAOs.DaoHabitacion();
            daoHabitacion.altasHabitacion(habitacion);
            JOptionPane.showMessageDialog(this, "Habitacion Registrada");
            
            txtId.setText("");
            txtNumero.setText("");
            txtTipo.setText("");
            txtEstado.setText("");
        });
        
        btnMostrar = new javax.swing.JButton("Mostrar");
        btnMostrar.setBounds(160, 200, 100, 40);
        btnMostrar.setBackground(new java.awt.Color(175, 238, 238));
        btnMostrar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnMostrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnMostrar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            //Abrir Reportes del Archivo
            //reportes.setVisible(true);
            
            //Abrir Reportes de MySQL
            CRUDHabitacion.MDHabitacion vMySQL = new CRUDHabitacion.MDHabitacion();
            vMySQL.setVisible(true);
        });
        
        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(320, 200, 100, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
        
            MenusOpciones.MPHabitacion menuPrincipal = new MenusOpciones.MPHabitacion();
            menuPrincipal.setVisible(true);
        });
        

        super.add(lblId);
        super.add(lblNumero);
        super.add(lblTipo);
        super.add(lblEstado);
        
        super.add(txtId);
        super.add(txtNumero);
        super.add(txtTipo);
        super.add(txtEstado);
        
        super.add(btnRegresar);
        super.add(btnGuardar);
        super.add(btnMostrar);
    }
}