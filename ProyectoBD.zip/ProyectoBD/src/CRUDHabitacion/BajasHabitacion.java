package CRUDHabitacion;
    import Clases.Habitacion;
    import DAOs.DaoHabitacion;
    import java.util.ArrayList;

public class BajasHabitacion extends javax.swing.JFrame {
    private java.util.ArrayList<Clases.Habitacion> habitacion;
    
    private int indiceActual = 0;
    
    private javax.swing.JLabel lblElegir;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblNumero;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JLabel lblEstado;

    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnRegresar;

    private javax.swing.JTextField txtID;

    public BajasHabitacion() {
        initComponents();
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 320;
        d.width = 640;
        
        super.setSize(d);
        setTitle("BAJAS HABITACIONES");
        setLayout(null);
        getContentPane().setBackground(new java.awt.Color(229,255,204));

        lblElegir = new javax.swing.JLabel("ID de la Habitación:");
        lblElegir.setBounds(50, 20, 180, 30);

        lblID = new javax.swing.JLabel("ID:");
        lblID.setBounds(50, 80, 180, 30);

        lblNumero = new javax.swing.JLabel("Número:");
        lblNumero.setBounds(50, 110, 180, 30);

        lblTipo = new javax.swing.JLabel("Tipo:");
        lblTipo.setBounds(50, 140, 180, 30);

        lblEstado = new javax.swing.JLabel("Estado:");
        lblEstado.setBounds(50, 170, 180, 30);

        btnBorrar = new javax.swing.JButton("Dar de Baja");
        btnBorrar.setBounds(250, 230, 130, 40);
        btnBorrar.setBackground(new java.awt.Color(175, 238, 238));
        btnBorrar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnBorrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBorrar.addActionListener((java.awt.event.ActionEvent e) -> {
            DaoHabitacion daoHabitacion = new DaoHabitacion();
            String idText = txtID.getText();

            try {
                int id = Integer.parseInt(idText);
                Habitacion habitacionBorrar = daoHabitacion.buscarHabitacion(id);

                if (habitacionBorrar != null) {
                    daoHabitacion.bajasHabitacion(id);
                    javax.swing.JOptionPane.showMessageDialog(this, "Habitación borrada exitosamente.");

                    mostrarDatos(habitacionBorrar);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "Habitación no encontrada.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID de la habitación.");
            }
            txtID.setText("");
        });

        btnBuscar = new javax.swing.JButton("Buscar");
        btnBuscar.setBounds(250, 20, 100, 30);
        btnBuscar.setBackground(new java.awt.Color(175, 238, 238));
        btnBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((java.awt.event.ActionEvent e) -> {
            DaoHabitacion daoHabitacion = new DaoHabitacion();
            String idText = txtID.getText();

            try {
                int id = Integer.parseInt(idText);
                Habitacion habitacion = daoHabitacion.buscarHabitacion(id);

                if (habitacion != null) {
                    mostrarDatos(habitacion);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "Habitación no encontrada.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID de la habitación.");
            }
            txtID.setText("");
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(410, 230, 130, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
        
            MenusOpciones.MPHabitacion menuPrincipal = new MenusOpciones.MPHabitacion();
            menuPrincipal.setVisible(true);
        });

        txtID = new javax.swing.JTextField();
        txtID.setBounds(180, 20, 60, 30);
        
        mostrarDatos(indiceActual);

        add(lblElegir);
        add(lblID);
        add(lblNumero);
        add(lblTipo);
        add(lblEstado);
        add(btnBorrar);
        add(btnBuscar);
        add(btnRegresar);
        add(txtID);
    }

    private void mostrarDatos(Habitacion habitacion) {
        if (habitacion != null) {
            lblID.setText("ID: " + habitacion.getId());
            lblNumero.setText("Número: " + habitacion.getNumero());
            lblTipo.setText("Tipo: " + habitacion.getTipo());
            lblEstado.setText("Estado: " + habitacion.getEstado());
        }  
    }

    private void mostrarDatos(int index) {
        DAOs.DaoHabitacion daoHabitacion = new DAOs.DaoHabitacion();
        habitacion = daoHabitacion.obtenerTodasHabitaciones();
        
        if (index >= 0 && index < habitacion.size()) {
            Clases.Habitacion habi = habitacion.get(index);
            lblID.setText("ID: " + habi.getId());
            lblNumero.setText("Número: " + habi.getNumero());
            lblTipo.setText("Tipo: " + habi.getTipo());
            lblEstado.setText("Estado: " + habi.getEstado());
        }    
            
    }
}
