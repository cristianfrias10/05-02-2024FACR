package CRUDMedico;
    import DAOs.DaoMedico;
    import Clases.Medico;
    import java.awt.Color;
    import java.awt.Dimension;
    import java.awt.Toolkit;
    import java.awt.event.ActionEvent;
    import javax.swing.*;

public class ModificarMedico extends JFrame {
    private java.util.ArrayList<Medico> medicos;
    private int indiceActual = 0;

    private JLabel lblTDatos;
    private JLabel lblId;
    private JLabel lblNombre;
    private JLabel lblApellidos;
    private JLabel lblEspecialidad;
    private JLabel lblTelefono;

    private JButton btnBuscar;
    private JButton btnModificar;
    private JButton btnRegresar;

    private JTextField txtModificar;
    private JTextField txtId;
    private JTextField txtNombre;
    private JTextField txtApellidos;
    private JTextField txtEspecialidad;
    private JTextField txtTelefono;

    public ModificarMedico() {
        super.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 400;
        d.width = 640;

        super.setSize(d);
        super.setTitle("MODIFICAR MEDICO");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(255,255,204));

        lblTDatos = new JLabel("INGRESA EL ID DEL MEDICO A MODIFICAR:");
        lblTDatos.setBounds(50, 20, 350, 30);

        lblId = new JLabel("ID:");
        lblId.setBounds(50, 70, 180, 30);

        lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(50, 100, 180, 30);

        lblApellidos = new JLabel("Apellidos:");
        lblApellidos.setBounds(50, 130, 180, 30);

        lblEspecialidad = new JLabel("Especialidad:");
        lblEspecialidad.setBounds(50, 160, 180, 30);

        lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(50, 190, 180, 30);

        txtModificar = new JTextField();
        txtModificar.setBounds(370, 20, 100, 30);

        txtId = new JTextField();
        txtId.setBounds(250, 70, 100, 30);

        txtNombre = new JTextField();
        txtNombre.setBounds(250, 100, 150, 30);

        txtApellidos = new JTextField();
        txtApellidos.setBounds(250, 130, 170, 30);

        txtEspecialidad = new JTextField();
        txtEspecialidad.setBounds(250, 160, 150, 30);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(250, 190, 170, 30);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(480, 20, 100, 30);
        btnBuscar.setBackground(new Color(175, 238, 238));
        btnBuscar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((ActionEvent e) -> {
            String idBuscar = txtModificar.getText().trim();

            if (idBuscar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese un ID a buscar.");
            } else {
                int id = Integer.parseInt(idBuscar);
                DaoMedico daoMedico = new DaoMedico();
                Medico medico = daoMedico.buscarMedico(id);

                if (medico != null) {
                    mostrarDatos(medico);
                } else {
                    JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                }

                txtModificar.setText("");
            }
        });

        btnModificar = new JButton("Modificar");
        btnModificar.setBounds(490, 100, 100, 40);
        btnModificar.setBackground(new Color(175, 238, 238));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnModificar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificar.addActionListener((ActionEvent e) -> {
            String idModificar = txtId.getText().trim();
            String nuevoNombre = txtNombre.getText().trim();
            String nuevosApellidos = txtApellidos.getText().trim();
            String nuevaEspecialidad = txtEspecialidad.getText().trim();
            String nuevoTelefono = txtTelefono.getText().trim();

            if (idModificar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor ingrese el ID del médico a modificar.");
                return;
            }

            int id = Integer.parseInt(idModificar);
            DaoMedico daoMedico = new DaoMedico();
            Medico medicoModificar = daoMedico.buscarMedico(id);

            if (medicoModificar == null) {
                JOptionPane.showMessageDialog(this, "El ID especificado no existe en la base de datos.");
                return;
            }

            if (!nuevoNombre.isEmpty()) {
                medicoModificar.setNombre(nuevoNombre);
            }
            if (!nuevosApellidos.isEmpty()) {
                medicoModificar.setApellidos(nuevosApellidos);
            }
            if (!nuevaEspecialidad.isEmpty()) {
                medicoModificar.setEspecialidad(nuevaEspecialidad);
            }
            if (!nuevoTelefono.isEmpty()) {
                medicoModificar.setTelefono(nuevoTelefono);
            }

            daoMedico.modificarMedico(medicoModificar);

            JOptionPane.showMessageDialog(this, "Los datos se han modificado correctamente.");

            txtId.setText("");
            txtNombre.setText("");
            txtApellidos.setText("");
            txtEspecialidad.setText("");
            txtTelefono.setText("");
        });

        btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(490, 150, 100, 40);
        btnRegresar.setBackground(new Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((ActionEvent e) -> {
            this.dispose();

            MenusOpciones.MPMedico menuPrincipal = new MenusOpciones.MPMedico();
            menuPrincipal.setVisible(true);
        });

        super.add(lblTDatos);
        super.add(lblId);
        super.add(lblNombre);
        super.add(lblApellidos);
        super.add(lblEspecialidad);
        super.add(lblTelefono);

        super.add(btnBuscar);
        super.add(btnModificar);
        super.add(btnRegresar);

        super.add(txtModificar);
        super.add(txtId);
        super.add(txtNombre);
        super.add(txtApellidos);
        super.add(txtEspecialidad);
        super.add(txtTelefono);

        mostrarDatos(indiceActual);
    }

    private void mostrarDatos(int index) {
        DaoMedico daoMedico = new DaoMedico();
        medicos = daoMedico.obtenerTodosMedicos();

        if (index >= 0 && index < medicos.size()) {
            Medico medico = medicos.get(index);
            lblId.setText("ID: " + medico.getId());
            lblNombre.setText("Nombre: " + medico.getNombre());
            lblApellidos.setText("Apellidos: " + medico.getApellidos());
            lblEspecialidad.setText("Especialidad: " + medico.getEspecialidad());
            lblTelefono.setText("Teléfono: " + medico.getTelefono());
        }
    }

    private void mostrarDatos(Medico medico) {
        if (medico != null) {
            lblId.setText("ID: " + medico.getId());
            lblNombre.setText("Nombre: " + medico.getNombre());
            lblApellidos.setText("Apellidos: " + medico.getApellidos());
            lblEspecialidad.setText("Especialidad: " + medico.getEspecialidad());
            lblTelefono.setText("Teléfono: " + medico.getTelefono());

            txtId.setText(String.valueOf(medico.getId()));
            txtNombre.setText(medico.getNombre());
            txtApellidos.setText(medico.getApellidos());
            txtEspecialidad.setText(medico.getEspecialidad());
            txtTelefono.setText(medico.getTelefono());
        }
    }
}