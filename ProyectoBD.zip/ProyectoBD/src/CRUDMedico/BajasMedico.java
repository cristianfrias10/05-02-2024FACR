package CRUDMedico;
    import javax.swing.*;
    import java.sql.SQLException;
    import java.util.ArrayList;
    import DAOs.DaoMedico;
    import Clases.Medico;

public class BajasMedico extends javax.swing.JFrame {
    private java.util.ArrayList<Clases.Medico> medicos;
    
    private int indiceActual = 0;
    
    private javax.swing.JLabel lblElegir;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblApellidos;
    private javax.swing.JLabel lblEspecialidad;
    private javax.swing.JLabel lblTelefono;

    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnBuscar;
    
    private javax.swing.JTextField txtElegir;
    
    public BajasMedico() {
        super("BAJAS MEDICOS");
        setSize(640, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new java.awt.Color(255,255,204));

        lblElegir = new javax.swing.JLabel("ID del Médico:");
        lblElegir.setBounds(50, 20, 180, 30);

        lblID = new javax.swing.JLabel("ID:");
        lblID.setBounds(50, 80, 180, 30);

        lblNombre = new javax.swing.JLabel("Nombre:");
        lblNombre.setBounds(50, 110, 180, 30);

        lblApellidos = new javax.swing.JLabel("Apellidos:");
        lblApellidos.setBounds(50, 140, 180, 30);

        lblEspecialidad = new javax.swing.JLabel("Especialidad:");
        lblEspecialidad.setBounds(50, 170, 180, 30);

        lblTelefono = new javax.swing.JLabel("Teléfono:");
        lblTelefono.setBounds(50, 200, 180, 30);

        btnBorrar = new javax.swing.JButton("Dar de Baja");
        btnBorrar.setBounds(460, 100, 130, 40);
        btnBorrar.setBackground(new java.awt.Color(175, 238, 238));
        btnBorrar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnBorrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBorrar.addActionListener((java.awt.event.ActionEvent e) -> {
            DAOs.DaoMedico daoMedico = new DAOs.DaoMedico();
            String idText = txtElegir.getText();
            
            try {
                int id = Integer.parseInt(idText);
                Clases.Medico medicoBorrar = daoMedico.buscarMedico(id);
                
                if (medicoBorrar != null) {
                    daoMedico.bajasMedico(id);
                    javax.swing.JOptionPane.showMessageDialog(this, "Médico borrado exitosamente.");
                    
                    lblID.setText("ID");
                    lblNombre.setText("Nombre");
                    lblApellidos.setText("Apellidos");
                    lblEspecialidad.setText("Especialidad");
                    lblTelefono.setText("Teléfono");
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "ID de Médico no encontrado.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID.");
            }
            txtElegir.setText("");
        });
        
        btnBuscar = new javax.swing.JButton("Buscar");
        btnBuscar.setBounds(350, 20, 100, 30);
        btnBuscar.setBackground(new java.awt.Color(175, 238, 238));
        btnBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener((java.awt.event.ActionEvent e)-> {
            DAOs.DaoMedico daoMedico = new DAOs.DaoMedico();
            String idText = txtElegir.getText();
            txtElegir.setText("");
            
            try {
                int id = Integer.parseInt(idText);
                Clases.Medico medico = daoMedico.buscarMedico(id);
                
                if (medico != null) {
                    mostrarDatos(medico);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "ID de Médico no encontrado.");
                }
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido en el ID.");
            }
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(460, 150, 130, 40);
        btnRegresar.setBackground(new java.awt.Color(192, 192, 192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();

            MenusOpciones.MPMedico menuPrincipal = new MenusOpciones.MPMedico();
            menuPrincipal.setVisible(true);
        });
        
        txtElegir = new javax.swing.JTextField();
        txtElegir.setBounds (180, 20, 150, 30);
        
        mostrarDatos(indiceActual);

        super.add(lblElegir);
        super.add(lblID);
        super.add(lblNombre);
        super.add(lblApellidos);
        super.add(lblEspecialidad);
        super.add(lblTelefono);
        
        super.add(btnBorrar);
        super.add(btnRegresar);
        super.add(btnBuscar);
        
        super.add(txtElegir);
        
    }

    private void mostrarDatos(int index) {
        DAOs.DaoMedico daoMedico = new DAOs.DaoMedico();
        medicos = daoMedico.obtenerTodosMedicos();
        
        if (index >= 0 && index < medicos.size()) {
            Clases.Medico medico = medicos.get(index);
            lblID.setText("ID: " + medico.getId());
            lblNombre.setText("Nombre: " + medico.getNombre());
            lblApellidos.setText("Apellidos: " + medico.getApellidos());
            lblEspecialidad.setText("Especialidad: " + medico.getEspecialidad());
            lblTelefono.setText("Teléfono: " + medico.getTelefono());
        }
    }
    
    private void mostrarDatos(Clases.Medico medico) {
        if (medico != null) {
            lblID.setText("ID: " + medico.getId());
            lblNombre.setText("Nombre: " + medico.getNombre());
            lblApellidos.setText("Apellidos: " + medico.getApellidos());
            lblEspecialidad.setText("Especialidad: " + medico.getEspecialidad());
            lblTelefono.setText("Teléfono: " + medico.getTelefono());
        }
    }
}
