package MenusOpciones;


public class MPHospitalizacion extends javax.swing.JFrame 
{
    private javax.swing.JButton btnAltas;
    private javax.swing.JButton btnBajas;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnReportes;
    private javax.swing.JButton btnRegresar;
    
    public MPHospitalizacion() 
    {
        super.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        java.awt.Dimension d = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        d.height = 320;
        d.width = 640;
        
        super.setSize(d);
        super.setTitle("MENU PRINCIPAL HOSPITALIZACION");
        super.setLayout(null);
        getContentPane().setBackground(new java.awt.Color(255,239,213));
        
        btnAltas = new javax.swing.JButton("Altas");
        btnAltas.setBounds(260, 20, 100, 40);
        btnAltas.setBackground(new java.awt.Color(135,206,235));
        btnAltas.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnAltas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAltas.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            CRUDHospitalizacion.AltasHospitalizacion altas = new CRUDHospitalizacion.AltasHospitalizacion();
            altas.setVisible(true);
        });

        btnBajas = new javax.swing.JButton("Bajas");
        btnBajas.setBounds(260, 70, 100, 40);
        btnBajas.setBackground(new java.awt.Color(135,206,235));
        btnBajas.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnBajas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBajas.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            CRUDHospitalizacion.BajasHospitalizacion bajas = new CRUDHospitalizacion.BajasHospitalizacion();
            bajas.setVisible(true);
        });
        
        btnModificar = new javax.swing.JButton("Modificar");
        btnModificar.setBounds(260, 120, 100, 40);
        btnModificar.setBackground(new java.awt.Color(135,206,235));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnModificar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            CRUDHospitalizacion.ModificarHospitalizacion modificar = new CRUDHospitalizacion.ModificarHospitalizacion();
            modificar.setVisible(true);
        });

        btnReportes = new javax.swing.JButton("Reportes");
        btnReportes.setBounds(260, 170, 100, 40);
        btnReportes.setBackground(new java.awt.Color(135,206,235));
        btnReportes.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnReportes.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnReportes.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            CRUDHospitalizacion.MDHospitalizacion reportes = new CRUDHospitalizacion.MDHospitalizacion();
            reportes.setVisible(true);
        });

        btnRegresar = new javax.swing.JButton("Regresar");
        btnRegresar.setBounds(260, 220, 100, 40);
        btnRegresar.setBackground(new java.awt.Color(192,192,192));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 18));
        btnRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegresar.addActionListener((java.awt.event.ActionEvent e) -> {
            this.dispose();
            
            MenuPrincipal.MP menuPrincipal = new MenuPrincipal.MP();
            menuPrincipal.setVisible(true);
        });
        
        super.add(btnAltas);
        super.add(btnBajas);
        super.add(btnModificar);
        super.add(btnReportes);
        super.add(btnRegresar);
        
    }
    
}
